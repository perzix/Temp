﻿
    using System.Collections.Generic;
    using System.Linq;
    using Sirenix.OdinInspector;
    using UnityEngine;

    [TypeInfoBox("스크롤 슬롯중 원하는 타겟이 있는 경우 사용")]
    public class TutorialHoleScrollRectElementTargetGetter : AbsTutorialHoleTargetGetter
    {
        [System.Serializable]
        public class TargetInfo : AbsTutorialHoleTargetGetter.AbsTargetInfo
        {
            [SerializeField] public RectTransform RectTransform;
            public override void GenerateId()
            {
                if (RectTransform != null)
                {
                    var transform = RectTransform.transform;
                    int depth = 0;
                    while (true)
                    {
                        if (transform.TryGetComponent<TutorialHoleScrollRectElementTargetGetter>(out _))
                        {
                            break;
                        }
                        transform = transform.parent;
                        depth++;
                    }
                    TutorialHoleId = depth == 0 ? transform.name : $"{transform.name}.{RectTransform.name}"; 
                }
            }
        }

        [SerializeField]
        private List<TargetInfo> _targetInfos = new List<TargetInfo>();
        public RectTransform GetTarget(string tutorialHoleId)
        {
            return (from t in _targetInfos where t.TutorialHoleId == tutorialHoleId select t.RectTransform).FirstOrDefault();
        }

        public override List<string> GetIds()
        {
            return _targetInfos.Select(e => e.TutorialHoleId).ToList();
        }
    }
