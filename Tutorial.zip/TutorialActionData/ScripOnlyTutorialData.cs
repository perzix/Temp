﻿//스크립트에서만 사용

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Sirenix.OdinInspector;
using UnityEngine;
using UnityEngine.Events;

public class TemplatePopupTutorial<T> : AbsHoleTutorialData where T : UIBase
{
    public override string GetComment()
    {
        return "";
    }
    public enum ProcessType
    {
        WaitForOpen,
        ForceOpen,
        Skip,
    }

    private GameObject _prefab;
    public ProcessType Type;

    [DisableInEditorMode]
    public string PrefabPath;

    public T Popup { get; private set; } 

    public void OnPrefabPathChange()
    {
        _prefab = null;

        var prefab = Util.LoadRes<GameObject>(PrefabPath.Replace(".prefab", ""));
        var component = prefab.GetComponent<T>();
        if (component == null)
        {
            Debug.Log($"[CommonPopupHoleTutorialData2][{typeof(T)} Type Not Found. PrefabPath : {PrefabPath}]");
            return;
        }

        _prefab = prefab;
        if (TargetInfo != null)
        {
            TargetInfo.OnChangePopupPrefab(_prefab);
        }
    }

    //오딘통해서 프리펩 드래그앤 드랍하면 경로가 설정될수 있게 하자
    [ShowInInspector, TypeFilter("GetFilteredTypeList")] [OnValueChanged("OnTargetInfoChange")]
    public AbsTargetInfo TargetInfo;

    public void OnTargetInfoChange()
    {
        if (string.IsNullOrEmpty(PrefabPath))
        {
            return;
        }

        if (_prefab == null)
        {
            _prefab = Util.LoadRes<GameObject>(PrefabPath.Replace(".prefab", ""));
        }

        if (TargetInfo != null)
        {
            TargetInfo.OnChangePopupPrefab(_prefab);
        }

        _prefab = null;
    }

    private static IEnumerable<Type> _filteredTypeList;

    public IEnumerable<Type> GetFilteredTypeList()
    {
        if (_filteredTypeList == null)
        {
            _filteredTypeList = typeof(AbsTargetInfo).Assembly.GetTypes()
                .Where(x => !x.IsAbstract) // Excludes BaseClass
                .Where(x => !x.IsGenericTypeDefinition) // Excludes C1<>
                .Where(x => typeof(AbsTargetInfo)
                    .IsAssignableFrom(x)); // Excludes classes not inheriting from BaseClass    
        }

        return _filteredTypeList;
    }

    public IEnumerator OpenPopup(UnityAction failCallback)
    {
        Popup = UIManager.Instance.GetPopupUIFromList<T>();
        if (Popup != null) yield break;
        if (Type == ProcessType.Skip) yield break;
        
        if (Type == ProcessType.ForceOpen)
        {
            Popup = UIManager.Instance.OpenUI<T>(PrefabPath.Replace(".prefab", ""));
        }
        else if (Type == ProcessType.WaitForOpen)
        {
            GameObject waitPopup = null; 
            var waitUntilWithTimeout = new WaitUntilWithTimeout(() =>
            {
                waitPopup = UIManager.Instance.GetPopupUIFromList(typeof(T));
                return waitPopup != null;
            }, 10);
            yield return waitUntilWithTimeout;
            if (waitUntilWithTimeout.IsTimeout)
            {
                failCallback.Invoke();
                yield break;
            }
            Popup = UIManager.Instance.GetPopupUIFromList<T>();
        }
    }


    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        if (Popup == null)
        {
            failCallback?.Invoke($"Popup is null {typeof(T)}");
            yield break;
        }

        RectTransform holeTarget = null;
        switch (TargetInfo)
        {
            case FixedTargetInfo fixedTargetInfo:
            {
                var getter = Popup.GetComponent<TutorialHoleFixedTargetGetter>();
                holeTarget = getter.GetTarget(fixedTargetInfo.HoleTargetId);
                break;
            }
            case ScrollTargetInfo scrollTargetInfo:
            {
                var getter = Popup.GetComponent<TutorialHoleScrollTargetGetter>();
                holeTarget = getter.GetTarget(scrollTargetInfo.ScrollId, scrollTargetInfo.SlotIndex,
                    scrollTargetInfo.HoleTargetId);
                break;
            }
            case EnhancedScrollTargetInfo enhancedScrollTargetInfo:
            {
                var getter = Popup.GetComponent<TutorialHoleEnhancedScrollTargetGetter>();
                holeTarget = getter.GetTarget(enhancedScrollTargetInfo.ScrollId,
                    enhancedScrollTargetInfo.DataIndex, enhancedScrollTargetInfo.HoleTargetId);
                break;
            }
        }
        

        if (holeTarget != null)
        {
            if (holeTarget.gameObject.activeSelf == false)
            {
                Debug.Log($"TemplatePopupTutorial[{typeof(T)}] holtTarget waiting for active");
                yield return new WaitUntil(() => holeTarget.gameObject.activeSelf);
            }
            yield return OpenTutorialHole(holeTarget);
        }
    }

    private void Reload()
    {
        OnPrefabPathChange();
    }
}