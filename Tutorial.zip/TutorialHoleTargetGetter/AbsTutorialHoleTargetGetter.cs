﻿
using System.Collections.Generic;
using System.Linq;
using EnhancedUI.EnhancedScroller;
using Sirenix.OdinInspector;
using UnityEngine;

public abstract class AbsTutorialHoleTargetGetter : MonoBehaviour
{
    public abstract class AbsTargetInfo
    {
        [InlineButton("GenerateId")]
        public string TutorialHoleId;

        public abstract void GenerateId();
    }

    public abstract List<string> GetIds();
}


