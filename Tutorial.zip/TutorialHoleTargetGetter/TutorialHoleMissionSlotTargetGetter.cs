﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class TutorialHoleMissionSlotTargetGetter : AbsTutorialHoleTargetGetter
{
    [System.Serializable]
    public class TargetInfo
    {
        public ScrollRect Scroll;
    }
    [SerializeField]
    private List<TargetInfo> _targetInfos = new List<TargetInfo>();

    public override List<string> GetIds()
    {
        return null;
    }
    
    public RectTransform GetTarget(int missionId)
    {
        for (int i = 0; i < _targetInfos.Count; ++i)
        {
            var targetInfo = _targetInfos[i];
            var slotCount = targetInfo.Scroll.content.childCount;

            for (int slotIndex = 0; slotIndex < slotCount; ++slotIndex)
            {
                var missionSlot = targetInfo.Scroll.content.GetChild(slotIndex).GetComponent<UIMissionSlot>();
                if (missionSlot == null || missionSlot.Data.Id != missionId)
                {
                    continue;
                }
                //타겟은 슬롯내에서 판단하도록하자
                if (missionSlot.SlotState == UIMissionSlot.ChapterSubslot_State.Available_Reward_Get)
                {
                    return missionSlot.BtnReward.GetComponent<RectTransform>();
                }
                if (missionSlot.SlotState == UIMissionSlot.ChapterSubslot_State.ShoutCut)
                {
                    return missionSlot.BtnShortCut.GetComponent<RectTransform>();
                }
                Debug.Log($"[TutorialHoleMissionSlotTargetGetter] Invalid SlotState. [{missionId}] [{missionSlot.SlotState}]");        
                return null;
            }
        }
        Debug.Log($"[TutorialHoleMissionSlotTargetGetter] Target Not Found. {missionId}");
        return null;
    }
    
}