﻿using System.Collections.Generic;
using System.Linq;
using Sirenix.OdinInspector;
using Tutorial;
using UnityEngine;

public class TutorialHoleFixedTargetGetter : AbsTutorialHoleTargetGetter
{
    [System.Serializable]
    public class TargetInfo : AbsTutorialHoleTargetGetter.AbsTargetInfo
    {
        [SerializeField] public RectTransform RectTransform;
        public override void GenerateId()
        {
            if (RectTransform != null)
            {
                var transform = RectTransform.transform;
                while (true)
                {
                    if (transform.TryGetComponent<TutorialHoleFixedTargetGetter>(out _))
                    {
                        break;
                    }
                    transform = transform.parent;
                }
                TutorialHoleId = $"{transform.name}.{RectTransform.name}"; 
            }
        }
    }

    [SerializeField]
    private List<TargetInfo> _targetInfos = new List<TargetInfo>();
    public RectTransform GetTarget(string tutorialHoleId)
    {
        return (from t in _targetInfos where t.TutorialHoleId == tutorialHoleId select t.RectTransform).FirstOrDefault();
    }

    public override List<string> GetIds()
    {
        return _targetInfos.Select(e => e.TutorialHoleId).ToList();
    }

    [Button(ButtonSizes.Large)]
    public void TutorialStepButtonMigration()
    {
        var tutorialStep = GetComponent<TutorialStep>();
        if (tutorialStep == null)
        {
            Debug.LogWarning("[TutorialStepButtonMigration] TutorialStep Not Found.");
            return;
        }
        foreach (var data in tutorialStep.data)
        {
            if (data.holeTarget.targetRect == null)
                continue;
            var targetInfo = new TargetInfo();
            targetInfo.RectTransform = data.holeTarget.targetRect;
            targetInfo.GenerateId();
            var find = _targetInfos.Find(e => e.TutorialHoleId == targetInfo.TutorialHoleId);
            if (find != null)
            {
                continue;
            }
            _targetInfos.Add(targetInfo);
        }
    }
}