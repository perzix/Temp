﻿using System.Collections;
using System.Collections.Generic;
using Sirenix.OdinInspector;
using UnityEngine;

public abstract class AbsTargetInfo
{
    [ValueDropdown("TargetIds")]
    public string HoleTargetId;

    protected List<string> _targetIdDropdownList = new List<string>();
    public abstract void OnChangePopupPrefab(GameObject popup);

    public virtual IEnumerable TargetIds()
    {
        if (_targetIdDropdownList == null)
        {
            yield break;
        }
        for (int i = 0; i < _targetIdDropdownList.Count; ++i)
        {
            yield return _targetIdDropdownList[i];
        }
        
    }
   
}
public class FixedTargetInfo : AbsTargetInfo
{
    public override void OnChangePopupPrefab(GameObject popup)
    {
        _targetIdDropdownList ??= new List<string>();
        _targetIdDropdownList.Clear();

        if (popup == null)
        {
            HoleTargetId = "";
            return;
        }
        
        var getter = popup.GetComponent<TutorialHoleFixedTargetGetter>();
        if (getter == null)
        {
            HoleTargetId = "";
            return;
        }
        _targetIdDropdownList.AddRange(getter.GetIds());
    }
}
public class ScrollTargetInfo : AbsTargetInfo
{
    [PropertyOrder(-1)]
    [ValueDropdown("GetScrollerIds"), OnValueChanged("OnChangeScrollId")]
    public string ScrollId;
    public int SlotIndex;
    
    private List<string> _scrollerIdDropdownList = new List<string>();
    private GameObject _prefab;
    public IEnumerable GetScrollerIds()
    {
        if (_scrollerIdDropdownList == null)
        {
            yield break;
        }
        for (int i = 0; i < _scrollerIdDropdownList.Count; ++i)
        {
            yield return _scrollerIdDropdownList[i];
        }
        
    }

    public void OnChangeScrollId()
    {
        OnSelectScollId(ScrollId);
    }
    
    public override void OnChangePopupPrefab(GameObject popup)
    {
        //ScrollerId를 먼저 한다.
        _prefab = popup;
        
        _scrollerIdDropdownList ??= new List<string>();
        _scrollerIdDropdownList.Clear();

        if (_prefab == null)
        {
            ScrollId = "";
            HoleTargetId = "";
            return;
        }
        var getter = _prefab.GetComponent<TutorialHoleScrollTargetGetter>();
        if (getter == null)
        {
            ScrollId = "";
            HoleTargetId = "";
            return;
        }
        _scrollerIdDropdownList.AddRange(getter.GetIds());    
        OnSelectScollId(ScrollId);
    }

    public void OnSelectScollId(string scrollId)
    {
        if (_prefab == null)
        {
            return;
        }
        var getter = _prefab.GetComponent<TutorialHoleScrollTargetGetter>();
        _targetIdDropdownList ??= new List<string>();
        _targetIdDropdownList.Clear();
        _targetIdDropdownList.AddRange(getter.GetSlotElementIds(scrollId));    
    }
}
public class EnhancedScrollTargetInfo : AbsTargetInfo
{
    [PropertyOrder(-1)]
    [ValueDropdown("GetScrollerIds"), OnValueChanged("OnChangeScrollId")]
    public string ScrollId;
    public int DataIndex;
    private List<string> _scrollerIdDropdownList = new List<string>();
    private GameObject _prefab;
    
    public IEnumerable GetScrollerIds()
    {
        if (_scrollerIdDropdownList == null)
        {
            yield break;
        }
        for (int i = 0; i < _scrollerIdDropdownList.Count; ++i)
        {
            yield return _scrollerIdDropdownList[i];
        }
        
    }
    public void OnChangeScrollId()
    {
        OnSelectScollId(ScrollId);
    }
    
    public override void OnChangePopupPrefab(GameObject popup)
    {
        _prefab = popup;
        
        _scrollerIdDropdownList ??= new List<string>();
        _scrollerIdDropdownList.Clear();

        if (_prefab == null)
        {
            ScrollId = "";
            HoleTargetId = "";
            return;
        }
        
        var getter = popup.GetComponent<TutorialHoleEnhancedScrollTargetGetter>();
        if (getter == null)
        {
            ScrollId = "";
            HoleTargetId = "";
            return;
        }
        _scrollerIdDropdownList.AddRange(getter.GetIds());
        OnSelectScollId(ScrollId);
    }
    public void OnSelectScollId(string scrollId)
    {
        if (_prefab == null)
        {
            return;
        }
        var getter = _prefab.GetComponent<TutorialHoleEnhancedScrollTargetGetter>();
        _targetIdDropdownList ??= new List<string>();
        _targetIdDropdownList.Clear();
        _targetIdDropdownList.AddRange(getter.GetSlotElementIds(scrollId));    
    }
}
