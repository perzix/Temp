﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Fun.Engine.Pb;
using Sirenix.OdinInspector;
using troops.com;
using Tutorial;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

/// <summary>
/// OdinInspector 를 적극적으로 사용했기때문에 OdinInspector 관련 기능을 알아두는것이 좋다.
/// https://odininspector.com
/// </summary>
public abstract class AbsTutorialData
{
    public abstract IEnumerator Process(UnityAction<string> failCallback);

    public virtual IEnumerator PostProcess()
    {
        yield break;
    }

    public abstract string GetComment();
}

public class WaitTutorialData : AbsTutorialData
{
    public float WaitTime = 0;

    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        UIManager.Instance.BlockTouch(99, UIManager.BlockTouchType.Tutorial);
        yield return new WaitForSeconds(WaitTime);
        UIManager.Instance.ReleaseTouch(UIManager.BlockTouchType.Tutorial);
    }

    public override string GetComment()
    {
        return $"{WaitTime} 초 대기";
    }
}
[GUIColor(1, 0, 0, 1)]
public class SaveForNextTutorial : AbsTutorialData
{
    public bool WaitForResponse = false;

    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        var info =  TutorialStepManager.Instance.GetCurrentInfo();
        TutorialStepManager.Instance.RequestSaveDataByTutorialAction(info.Main, info.NextIndex);
        if (WaitForResponse)
        {
            var wait = new WaitUntilWithTimeout(() =>  TutorialStepManager.Instance.IsReceiveSavePacket);
            yield return wait;
            if (wait.IsTimeout)
            {
                failCallback?.Invoke("Timeout");
            }
        }
    }

    public override string GetComment()
    {
        return "";
    }
}

public abstract class AbsHoleTutorialData : AbsTutorialData
{
    private UITutorialHole.HoleType HoleType = UITutorialHole.HoleType.None;
    public int ClickSoundId = 10013;
    public Vector2 ExtendSize = Vector2.zero;
    public Vector2 HolePosition = Vector2.zero;
    public float StartDelay = 0f;
    public float EndDelay = 0f;

    protected bool _isHoleClick = false;

    protected virtual IEnumerator OpenTutorialHole(RectTransform rectTrans)
    {
        _isHoleClick = false;
        if (StartDelay.IsZero() == false)
        {
            UIManager.Instance.BlockTouch(99, UIManager.BlockTouchType.Tutorial);
            yield return new WaitForSeconds(StartDelay);
        }
        TutorialGuide.Instance.OpenTutorialHole(HoleType, rectTrans, ClickSoundId, HolePosition, ExtendSize,
            () => { _isHoleClick = true; });
        UIManager.Instance.ReleaseTouch(UIManager.BlockTouchType.Tutorial);
        yield return new WaitUntil(() => _isHoleClick);

        UIManager.Instance.BlockTouch(99, UIManager.BlockTouchType.Tutorial);
        if (EndDelay.IsZero() == false)
        {
            yield return new WaitForSeconds(EndDelay);
        }
        yield return null; //팝업이 제대로 셋팅되기전에 클릭 이벤트가 먼저 오는 경우가 있어서 한프레임 쉬도록함
        
    }

    public override IEnumerator PostProcess()
    {
        _isHoleClick = false;
        TutorialGuide.Instance.CloseTutorialHole();
        yield break;
    }
}

public abstract class AbsCameraMoveTutorialData : AbsTutorialData
{
    public float StartDelay = 0f;
    public float EndDelay = 0f;
    public float MoveSpeed = 6f;

    protected IEnumerator Move(Vector3 pos)
    {
        if (MoveSpeed.IsZero())
        {
            yield break;
        }

        UIManager.Instance.BlockTouch(30f + StartDelay + EndDelay, UIManager.BlockTouchType.Tutorial);
        if (StartDelay.IsZero() == false)
        {
            yield return new WaitForSeconds(StartDelay);
        }

        TerritorySNGControl._inst.AutoScrollCamera(pos, false, MoveSpeed);
        yield return new WaitUntil(() => TerritorySNGControl._inst.IsArriveAutoCamera());
        if (EndDelay.IsZero() == false)
        {
            yield return new WaitForSeconds(EndDelay);
        }
    }
}

public abstract class AbsCameraZoomTutorialData : AbsTutorialData
{
    public float ZoomDistance;
    public float ZoomTime;
    public AnimationCurve ZoomCurve;
}

[InfoBox("웹툰 애니메이션 출력")]
public class ScriptTutorialData : AbsTutorialData
{
    public int ScriptId;
    public float StartDelay = 0f;
    public float EndDelay = 0f;

    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        UIManager.Instance.BlockTouch(10.0f + StartDelay + EndDelay, UIManager.BlockTouchType.Tutorial);

        if (StartDelay.IsZero() == false)
        {
            yield return new WaitForSeconds(StartDelay);
        }

        TutorialGuide.Instance.CloseTutorialHole(false);

        //웹툰 재생
        yield return  TutorialStepManager.Instance.CharacterScriptsPopup(ScriptId);

        if (EndDelay.IsZero() == false)
        {
            yield return new WaitForSeconds(EndDelay);
        }

        UIManager.Instance.ReleaseTouch(UIManager.BlockTouchType.Tutorial);
    }

    public override string GetComment()
    {
        return $"{ScriptId} 웹툰 출력";
    }
}
[InfoBox("영지 카메라 줌 설정")]
public class TerritoryCameraZoomTutorialData : AbsCameraZoomTutorialData
{
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
     
        if (MainControl.CurrentMode != MainControl.Mode.Territory)
        {
            WorldToTerritoryTutorialData waitData = new WorldToTerritoryTutorialData();
            yield return waitData.Process(failCallback);
        }
        var zoomDistance = Mathf.Clamp(ZoomDistance, TerritorySNGControl._inst.CameraDistanceMin,
            TerritorySNGControl._inst.CameraDistanceMax);
        UIManager.Instance.BlockTouch(30f, UIManager.BlockTouchType.Tutorial);
        WorldControl._inst.AutoScrollZoomCurveCamera(zoomDistance, ZoomTime, ZoomCurve);
        yield return new WaitUntil(() => TerritorySNGControl._inst.IsArriveAutoZoomCurveCamera());
        UIManager.Instance.ReleaseTouch(UIManager.BlockTouchType.Tutorial);
    }
    public override string GetComment()
    {
        return $"영지 카메라 줌 설정";
    }
}

[InfoBox("영지내 특정 건물로 카메라 이동")]
public class TerritoryCameraMoveTutorialData : AbsCameraMoveTutorialData
{
    public PEnumModelProtoEnumrefBuildingTypeWrapper.Types.PEnumModelProtoEnumrefBuildingType BuildingType;
    public override string GetComment()
    {
        return $"{BuildingType} 건물로 카메라 이동";
    }
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        if (MainControl.CurrentMode != MainControl.Mode.Territory)
        {
            WorldToTerritoryTutorialData waitData = new WorldToTerritoryTutorialData();
            yield return waitData.Process(failCallback);
        }

        TerritoryBldgData bldgData =
            TerritorySNGControl._inst._myBldgInfos.Values.FirstOrDefault(bldg =>
                bldg._buildingType == BuildingType);

        if (bldgData == null)
        {
            UIManager.Instance.ReleaseTouch(UIManager.BlockTouchType.Tutorial);
            failCallback?.Invoke("bldgData is null");
            yield break;
        }

        Vector3 pos;

        if (bldgData.TerritorySNGBldg != null)
            pos = bldgData.TerritorySNGBldg.transform.position;
        else
        {
            Vector2Int cellIndex = TerritoryUtil.GetOffsetById(bldgData._territoryTileID);
            pos = TerritoryUtil.GetCellIndexToWorldPos(cellIndex);
        }

        yield return Move(pos);
    }
}
[InfoBox("영지내 특정 Cell로 카메라 이동")]
public class TerritoryCellCameraMove : AbsCameraMoveTutorialData
{
    public Vector2Int CellIndex;
    public override string GetComment()
    {
        return $"영지내 {CellIndex.x}, {CellIndex.y} 로 카메라 이동";
    }
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        if (MainControl.CurrentMode != MainControl.Mode.Territory)
        {
            WorldToTerritoryTutorialData waitData = new WorldToTerritoryTutorialData();
            yield return waitData.Process(failCallback);
        }
        var pos = TerritoryUtil.GetCellIndexToWorldPos(CellIndex);
        yield return Move(pos);
    }
}
[InfoBox("영지레이아웃 변경")]
public class TerritoryLayoutChange : AbsTutorialData
{
    public int LayoutId;
    public bool WaitForChange;
    public override string GetComment()
    {
        return $"{LayoutId} 영지레이아웃 변경";
    }
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        if (MainControl.CurrentMode != MainControl.Mode.Territory)
        {
            WorldToTerritoryTutorialData waitData = new WorldToTerritoryTutorialData();
            yield return waitData.Process(failCallback);
        }

        if (WaitForChange)
        {
            bool isLayoutChanged = false;
            TerritorySNGControl._inst.RequestTerritoryLayout(LayoutId, ()=> isLayoutChanged = true);
            yield return new WaitUntilWithTimeout(() => isLayoutChanged);
        }
    }
}

[InfoBox("월드 카메라 줌 설정")]
public class WorldCameraZoomTutorialData : AbsCameraZoomTutorialData
{
    public override string GetComment()
    {
        return $"월드 카메라 줌 설정";
    }
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        var zoomDistance = Mathf.Clamp(ZoomDistance, WorldControl._inst.CameraDistanceMin,
            WorldControl._inst.CameraDistanceMax);
        if (MainControl.CurrentMode != MainControl.Mode.World)
        {
            WaitingForChangeModeTutorialData changeMode = new WaitingForChangeModeTutorialData();
            changeMode.Mode = MainControl.Mode.World;
            TerritorySNGControl._inst.EnterWorld();
            yield return changeMode.Process(failCallback);
        }

        UIManager.Instance.BlockTouch(30f, UIManager.BlockTouchType.Tutorial);
        WorldControl._inst.AutoScrollZoomCurveCamera(zoomDistance, ZoomTime, ZoomCurve);
        yield return new WaitUntil(() => WorldControl._inst.IsArriveAutoZoomCurveCamera());
    }
}

[InfoBox("월드오브젝트 카메라 이동 설정")]
public class WorldCameraMoveTutorialData : AbsCameraMoveTutorialData
{
    [ValueDropdown("GetTypes")] public PWorldObjectTypeEnum.Types.PWorldObjectType WorldObjectType;

    private List<PWorldObjectTypeEnum.Types.PWorldObjectType> _worldObjectTypes = null;
    public override string GetComment()
    {
        return $"{WorldObjectType} 카메라 이동 설정";
    }
    public IEnumerable GetTypes()
    {
        if (_worldObjectTypes == null)
        {
            _worldObjectTypes = new List<PWorldObjectTypeEnum.Types.PWorldObjectType>
            {
                PWorldObjectTypeEnum.Types.PWorldObjectType.SuperCastle,
                PWorldObjectTypeEnum.Types.PWorldObjectType.GateOuterCenter
            };
        }

        for (int i = 0; i < _worldObjectTypes.Count; ++i)
        {
            yield return _worldObjectTypes[i];
        }
    }

    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        UIManager.Instance.BlockTouch(30f, UIManager.BlockTouchType.Tutorial);
        if (MainControl.CurrentMode != MainControl.Mode.World)
        {
            WaitingForChangeModeTutorialData enterWorld = new WaitingForChangeModeTutorialData()
            {
                Mode = MainControl.Mode.World
            };
            TerritorySNGControl._inst.EnterWorld();
            yield return enterWorld.Process(failCallback);
        }

        WorldControl._inst.AutoScrollZoomCamera(GetWorldObjectPos(WorldObjectType), 30.0f, MoveSpeed);
        yield return new WaitUntil(() => WorldControl._inst.IsArriveAutoCamera());
    }

    private Vector3 GetWorldObjectPos(PWorldObjectTypeEnum.Types.PWorldObjectType worldObjectType)
    {
        if (worldObjectType == PWorldObjectTypeEnum.Types.PWorldObjectType.SuperCastle)
            return new Vector3(474.0f, 0.0f, 522.0f);
        if (worldObjectType == PWorldObjectTypeEnum.Types.PWorldObjectType.GateOuterCenter)
            return new Vector3(532.0f, 0.0f, 481.0f);
        return Vector3.one;
    }
}
[InfoBox("특정모드로 변경 완료될때까지 대기")]
public class WaitingForChangeModeTutorialData : AbsTutorialData
{
    public MainControl.Mode Mode;
    public override string GetComment()
    {
        return $"{Mode} 모드로 변경 완료될때까지 대기";
    }
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        GameObject hudGameObject = null;
        if (MainControl.CurrentMode != Mode)
        {
            yield return new WaitUntil(() => MainControl.CurrentMode == Mode);
        }
        switch (Mode)
        {
            case MainControl.Mode.World:
            {
                hudGameObject = UIWorldHud._inst.gameObject;
                break;
            }
            case MainControl.Mode.Territory:
            {
                hudGameObject = UITerritoryHud._inst.gameObject;
                break;
            }
            case MainControl.Mode.ZoneStage:
            {
                hudGameObject = UIZoneStageHud._inst.gameObject;
                break;
            }
        }
        yield return new WaitUntil(() => hudGameObject == null || hudGameObject.activeSelf);

        
    }
}

//몬가 스킵 조건 같은게 있었으면 좋겠다(보통은 팝업띄우려고 쓰는거니 해당 팝업이 있으면 넘어간다던지?)
public class TerritoryHudTutorialData : AbsHoleTutorialData
{
    private GameObject _prefab;

    [OnValueChanged("OnPrefabPathChange"), InlineButton("Reload")]
    [Sirenix.OdinInspector.FilePath(ParentFolder = "Assets/ResourceBundle/", Extensions = "prefab")]
    public string PrefabPath;

    [OnValueChanged("OnTargetInfoChange")] public FixedTargetInfo TargetInfo;

    [DisableInEditorMode] public Type _hudType;

    private GameObject _skipPopupPrefab;

    [OnValueChanged("OnSkipPopupPrefabPathPathChange"), InlineButton("PopupReload", "Reload")]
    [Sirenix.OdinInspector.FilePath(ParentFolder = "Assets/ResourceBundle/", Extensions = "prefab")]
    public string SkipPopupPrefabPath;


    [DisableInEditorMode] public Type _skipIfOpenPopupType;
    public override string GetComment()
    {
        return $"{_hudType} {TargetInfo.HoleTargetId} 홀 표시";
    }
    private void OnPrefabPathChange()
    {
        _prefab = null;
        if (string.IsNullOrEmpty(PrefabPath) == false)
        {
            _prefab = Util.LoadRes<GameObject>(PrefabPath.Replace(".prefab", ""));
        }

        if (TargetInfo != null)
        {
            TargetInfo.OnChangePopupPrefab(_prefab);
        }

        _hudType = _prefab != null ? _prefab.GetComponent<UIHudBase>().GetType() : null;
    }

    private void OnSkipPopupPrefabPathPathChange()
    {
        _prefab = null;
        if (string.IsNullOrEmpty(SkipPopupPrefabPath) == false)
        {
            _prefab = Util.LoadRes<GameObject>(SkipPopupPrefabPath.Replace(".prefab", ""));
        }

        _skipIfOpenPopupType = _prefab != null ? _prefab.GetComponent<UIPopupBase>().GetType() : null;
    }

    private void Reload()
    {
        OnPrefabPathChange();
    }

    private void PopupReload()
    {
        OnSkipPopupPrefabPathPathChange();
    }

    public void OnTargetInfoChange()
    {
        if (string.IsNullOrEmpty(PrefabPath))
        {
            return;
        }

        if (_prefab == null)
        {
            _prefab = Util.LoadRes<GameObject>(PrefabPath.Replace(".prefab", ""));
        }

        if (TargetInfo != null)
        {
            TargetInfo.OnChangePopupPrefab(_prefab);
        }

        _prefab = null;
    }


    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        ActiveHUDTutorialData activeHUD = new ActiveHUDTutorialData
        {
            IsActive = true
        };
        yield return activeHUD.Process(null);
        RectTransform holeTarget = null;
        if (TargetInfo == null)
        {
            yield break;
        }

        if (_skipIfOpenPopupType != null)
        {
            var popup = UIManager.Instance.GetPopupUIFromList(_skipIfOpenPopupType);
            if (popup != null)
            {
                yield break;
            }
        }

        if (_hudType == typeof(UIMainHud))
        {
            var getter = UIMainHud._inst.GetComponent<TutorialHoleFixedTargetGetter>();
            holeTarget = getter.GetTarget(TargetInfo.HoleTargetId);
        }
        else if (_hudType == typeof(UITerritoryHud))
        {
            var getter = UITerritoryHud._inst.GetComponent<TutorialHoleFixedTargetGetter>();
            holeTarget = getter.GetTarget(TargetInfo.HoleTargetId);
        }
        else if (_hudType == typeof(UIWorldHud))
        {
            var getter = UIWorldHud._inst.GetComponent<TutorialHoleFixedTargetGetter>();
            holeTarget = getter.GetTarget(TargetInfo.HoleTargetId);
        }
        else if (_hudType == typeof(UIZoneStageHud))
        {
            var getter = UIZoneStageHud._inst.GetComponent<TutorialHoleFixedTargetGetter>();
            holeTarget = getter.GetTarget(TargetInfo.HoleTargetId);
        }
        else if (_hudType == typeof(UITerritoryBuildHud))
        {
            var getter = UIManager.TerritoryBuildHudUI.GetComponent<TutorialHoleFixedTargetGetter>();
            holeTarget = getter.GetTarget(TargetInfo.HoleTargetId);
        }
        UIManager.Instance.CloseAllPopupUI();

        if (holeTarget != null)
        {
            yield return Helper.WaitForActiveTutorialHole(holeTarget);
            yield return OpenTutorialHole(holeTarget);
        }
    }
}


[InfoBox("영지내 특정 존 으로 카메라 이동")]
public class TerritoryZoneObjectCameraMoveTutorialData : AbsCameraMoveTutorialData
{
    public override string GetComment()
    {
        return $"{ZoneId} 존 으로 카메라 이동";
    }
    
    public int ZoneId;

    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        PModelTerritoryZone modelZone = ModelTerritoryZone.Instance.GetModel(ZoneId);
        if (modelZone == null)
        {
            yield break;
        }

        if (MainControl.CurrentMode != MainControl.Mode.Territory)
        {
            WorldToTerritoryTutorialData waitData = new WorldToTerritoryTutorialData();
            yield return waitData.Process(failCallback);
        }

        if (TerritorySNGControl._inst._dictModelZoneIDMappingbyZoneObjectIndex.TryGetValue(ZoneId,
                out var zoneIndex) == false)
        {
            failCallback.Invoke("Can`t Find ZoneId");
            yield break;
        }

        Vector3 cameraMovePosition;
        if (TerritorySNGControl._inst._dictZoneObject.TryGetValue(zoneIndex, out var zoneObject))
        {
            cameraMovePosition = zoneObject.transform.position;
        }
        else
        {
            //없으면 그냥 zoneIndex를 통해 위치 계산한다.
            int zoneTileid = TerritoryUtil.GetIdByOffset(TerritoryUtil.GetZoneOffsetByZoneID(zoneIndex));
            Vector2Int cellIndex = TerritoryUtil.GetOffsetById(zoneTileid);
            cameraMovePosition = TerritoryUtil.GetCellIndexToWorldPos(cellIndex);
        }

        yield return Move(cameraMovePosition);
    }
}

[InfoBox("월드 -> 영지로 이동")]
public class WorldToTerritoryTutorialData : AbsCameraMoveTutorialData
{
    public enum Step
    {
        None,
        ShowCloud,
        HideCloud,
    }

    private Step _step = Step.None;
    public override string GetComment()
    {
        return $"월드 -> 영지로 이동";
    }
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        if (MainControl.CurrentMode == MainControl.Mode.Territory)
        {
            yield break;
        }

        UIManager.Instance.LoadingCloud.ShowCloud(() => { _step = Step.ShowCloud; });
        yield return new WaitUntil(() => _step == Step.ShowCloud);

        MainControl._inst.ChangeNextMode(MainControl.Mode.Territory);
        UIManager.Instance.LoadingCloud.HideCloud(() => { _step = Step.HideCloud; });
        yield return new WaitUntil(() => _step == Step.HideCloud);
    }
}

[InfoBox("특정 존 풍선에 홀 표시")]
public class ZoneExtendTutorialData : AbsHoleTutorialData
{
    public override string GetComment()
    {
        return $"{ZoneId}존 {TutorialHoleId} 에 홀 표시";
    }
    private List<string> _targetIdDropdownList = new List<string>();

    private const string PrefabPath = "UI/Territory/SNG/SNGZoneExtend";
    public int ZoneId;
    [ValueDropdown("TargetIds")] public string TutorialHoleId;


    [Button("LoadPrefab", ButtonSizes.Small)]
    private void LoadPrefab()
    {
        _targetIdDropdownList ??= new List<string>();
        _targetIdDropdownList.Clear();
        var prefab = Util.LoadRes<GameObject>(PrefabPath);
        var getter = prefab.GetComponent<TutorialHoleFixedTargetGetter>();
        if (getter == null)
        {
            TutorialHoleId = "";
            return;
        }

        _targetIdDropdownList.AddRange(getter.GetIds());
    }

    public IEnumerable TargetIds()
    {
        if (_targetIdDropdownList == null)
        {
            yield break;
        }

        for (int i = 0; i < _targetIdDropdownList.Count; ++i)
        {
            yield return _targetIdDropdownList[i];
        }
    }


    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        if (MainControl.CurrentMode != MainControl.Mode.Territory)
        {
            WorldToTerritoryTutorialData waitData = new WorldToTerritoryTutorialData();
            yield return waitData.Process(failCallback);
        }

        if (Helper.IsZoneOpen(ZoneId))
        {
            //이미 존이 열려있으면 다음으로 넘어감
            failCallback?.Invoke("Already Zone Open");
            yield break;
        }

        //ZoneExtend중에 특정 건물의 ZoneExtend를 알아와야 한다.
        var zoneExtend = TerritorySNGControl._inst._dictZoneUIByTileID.Values.ToList<UISNGZoneExtend>()
            .Find(item => item.ZoneID == ZoneId);

        if (zoneExtend == null)
        {
            failCallback?.Invoke("Can`t Find ZoneUI");
            yield break;
        }

        var getter = zoneExtend.GetComponent<TutorialHoleFixedTargetGetter>();
        if (getter == null)
        {
            failCallback?.Invoke("TutorialHoleFixedTargetGetter is null");
            yield break;
        }

        TerritoryZoneObjectCameraMoveTutorialData cameraMoveTutorialData = new TerritoryZoneObjectCameraMoveTutorialData();
        cameraMoveTutorialData.ZoneId = ZoneId;
        yield return cameraMoveTutorialData.Process(null);
        var rectTrans = getter.GetTarget(TutorialHoleId);
        if (rectTrans != null)
        {
            yield return OpenTutorialHole(rectTrans);
        }
    }
}


public class TerritoryZonePurificationPopupTutorialData : AbsHoleTutorialData
{
    private GameObject _prefab;
    [OnValueChanged("OnPrefabPathChange"), InlineButton("Reload")]
    [Sirenix.OdinInspector.FilePath(ParentFolder = "Assets/ResourceBundle/", Extensions = "prefab")]
    public string PrefabPath = "UI/Territory/TerritoryZone/TerritoryZonePurificationPopup";
    public FixedTargetInfo TargetInfo;
    [DisableInEditorMode] public Type _popupType;
    public void OnPrefabPathChange()
    {
        _prefab = null;

        _prefab = Util.LoadRes<GameObject>(PrefabPath.Replace(".prefab", ""));
        if (_prefab.TryGetComponent<AbsUITerritoryZonePopup>(out _) == false)
        {
            Debug.LogError($"[TerritoryZonePurificationPopupTutorialData] Invalid TerritoryZonePopup Path : {PrefabPath}");
            PrefabPath = "";
            _prefab = null;
        }
        if (TargetInfo != null)
        {
            TargetInfo.OnChangePopupPrefab(_prefab);
        }

        _popupType = _prefab != null ? _prefab.GetComponent<UIPopupBase>().GetType() : null;
    }
    private void Reload()
    {
        OnPrefabPathChange();
    }
    
    
    public override string GetComment()
    {
        return $"{ZoneId} 존 {TargetInfo.HoleTargetId} 홀 표시";
    }
    public int ZoneId;

    //private const string PrefabPath = "UI/Territory/TerritoryZone/TerritoryZonePurificationPopup";

    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        if (Helper.IsZoneOpen(ZoneId))
        {
            //이미 존이 열려있으면 다음으로 넘어감
            failCallback?.Invoke("Already Zone Open");
            yield break;
        }

        var popup = UIManager.Instance.GetPopupUIFromList(_popupType);
        if (popup == null)
        {
            var zoneExtend = TerritorySNGControl._inst._dictZoneUIByTileID.Values.ToList<UISNGZoneExtend>()
                .Find(item => item.ZoneID == ZoneId);
            if (zoneExtend == null)
            {
                failCallback?.Invoke("Can`t Find ZoneUI");
                yield break;
            }

            var zonePopup = UIManager.Instance.OpenUI<AbsUITerritoryZonePopup>(PrefabPath);
            zonePopup.Init(ZoneId, zoneExtend.ZoneTileID);
            popup = zonePopup.gameObject;
            yield return null;
        }

        //고정된 버튼은 이걸 사용함
        var getter = popup.GetComponent<TutorialHoleFixedTargetGetter>();
        RectTransform holeTarget = null;
        if (getter != null)
        {
            holeTarget = getter.GetTarget(TargetInfo.HoleTargetId);
        }

        if (holeTarget != null)
        {
            yield return OpenTutorialHole(holeTarget);
        }

        var model = ModelTerritoryZone.Instance.GetModel(ZoneId);
        //보상팝업이 닫히고 존이 열리기때문에 기다리지 않는다.
        if (model.IsShowRewardAndZoneOpen() == false)
        {
            //존 열릴때까지 대기
            yield return new WaitUntil(() => Helper.IsZoneOpen(ZoneId));    
        }
        
    }
}

[System.Serializable]
[InfoBox("챕터 미션 팝업 슬롯 튜토리얼홀")]
public class MissionPopupTutorialData : AbsHoleTutorialData
{
    public override string GetComment()
    {
        return $"미션 팝업 {MissionId} {MissionSlotButtonType} 슬롯 튜토리얼홀";
    }
    public enum ButtonType
    {
        None,
        ReceiveReward,
        Shortcut,
        ChapterReward
    }

    [ShowIf("@this.MissionSlotButtonType != ButtonType.ChapterReward")]
    public int MissionId;
    public ButtonType MissionSlotButtonType = ButtonType.None;

    
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        
        bool isMissionComplete = false;
        bool canReceiveReward = false;
        bool canReceiveChapterReward = false;

        int currentChapterId = MissionManager.Instance.CurrentChapterID;
        if (MissionSlotButtonType == ButtonType.ChapterReward)
        {
            if (MissionManager.Instance.Chapter.TryGetValue(currentChapterId,
                    out var chapterMissions))
            {
                canReceiveChapterReward = (chapterMissions.Values.FirstOrDefault(miss => !miss.IsReward) == null);    
            }
        }
        else
        {
            var modelMission = ModelMission.Instance.GetModel(MissionId);
            if (MissionManager.Instance.Chapter.TryGetValue(modelMission.CategoryId, out var missions) &&
                missions.TryGetValue(modelMission.MissionId, out var mission) && mission.Count >= mission.GetMaxCount())
            {
                isMissionComplete = true;
                canReceiveReward = mission.IsReward == false;
            }
        }
        

        //미션 진행 튜토리얼인데 이미 미션을 완료 했으면 해당 튜토리얼 완료 처리 

        if (MissionSlotButtonType == ButtonType.Shortcut && isMissionComplete)
        {
            //다음 튜토리얼 진행
            failCallback?.Invoke("AlreadyCompleteMission");
            yield break;
        }
        else if (MissionSlotButtonType == ButtonType.ReceiveReward && isMissionComplete && canReceiveReward == false) //보상 받기 튜토리얼인데 이미 보상을 받았으면 튜토리얼 완료 처리.
        {
            //다음 튜토리얼 진행
            failCallback?.Invoke("AlreadyReceiveReward");
            yield break;
        }
        else if (MissionSlotButtonType == ButtonType.ChapterReward && canReceiveChapterReward == false)
        {
            failCallback?.Invoke("CantReceiveChapterReward");
            yield break;
        }

        var popup = UIManager.Instance.GetPopupUIFromList<UIChapterMissionPopup>();
        if (popup == null)
        {
            //팝업을 모두 닫고 미션 버튼 누르라고 하자
            UIManager.Instance.CloseAllUI();
            TerritoryHudTutorialData data = new TerritoryHudTutorialData()
            {
                TargetInfo = new FixedTargetInfo()
                {
                    HoleTargetId = "MainHudPanel.QuestButton"
                },
                _hudType =  typeof(UIMainHud),
            };
            yield return data.Process(null);
            popup = UIManager.Instance.GetPopupUIFromList<UIChapterMissionPopup>();
            if (popup == null)
            {
                failCallback?.Invoke("ChapterMissionPopup not Open");
                yield break;
            }
            yield return data.PostProcess();
        }

        RectTransform holeTarget = null;
        if (MissionSlotButtonType == ButtonType.ChapterReward)
        {
            var getter = popup.GetComponent<TutorialHoleFixedTargetGetter>();
            holeTarget = getter.GetTarget("ChapterMissionPopup.Button");
        }
        else
        {
            var getter = popup.GetComponent<TutorialHoleMissionSlotTargetGetter>();
            holeTarget = getter.GetTarget(MissionId);    
        }
        
        //var holeTarget = popup.GetMissionSlotTarget(MissionId);
        if (holeTarget == null)
        {
            failCallback?.Invoke("holeTarget not found.");
            yield break;
        }
        yield return OpenTutorialHole(holeTarget);

        if (MissionSlotButtonType == ButtonType.ReceiveReward)
        {
            var modelMission = ModelMission.Instance.GetModel(MissionId);
            var waitUntilWithTimeout = new WaitUntilWithTimeout(() =>
            {
                return MissionManager.Instance.Chapter.TryGetValue(modelMission.CategoryId, out var missions) &&
                       missions.TryGetValue(modelMission.MissionId, out var mission) && mission.IsReward;
            }, 10f);
            yield return waitUntilWithTimeout;
            if (waitUntilWithTimeout.IsTimeout)
            {
                failCallback?.Invoke($"[{MissionSlotButtonType}] Timeout");
                yield break;
            }
        }
        else if (MissionSlotButtonType == ButtonType.ChapterReward)
        {
            var waitUntilWithTimeout = new WaitUntilWithTimeout(() =>
            {
                return MissionManager.Instance.Chapter.TryGetValue(currentChapterId,
                    out var chapterMissions) && chapterMissions.Values.Any(e => e.IsReward);
            }, 10f);
            yield return waitUntilWithTimeout;
            if (waitUntilWithTimeout.IsTimeout)
            {
                failCallback?.Invoke($"[{MissionSlotButtonType}] Timeout");
                yield break;
            }
        }
    }
}

[System.Serializable]
[InfoBox("건물 선택")]
public class BldgSelectTutorialData : AbsHoleTutorialData
{
    public override string GetComment()
    {
        return $"{BuildingType} 선택";
    }
    public PEnumModelProtoEnumrefBuildingTypeWrapper.Types.PEnumModelProtoEnumrefBuildingType BuildingType;

    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        UIManager.Instance.CloseAllPopupUI();
        TerritoryBldgData bldgData =
            TerritorySNGControl._inst._myBldgInfos.Values.FirstOrDefault(bldg =>
                bldg._buildingType == BuildingType);

        if (bldgData == null)
        {
            UIManager.Instance.ReleaseTouch(UIManager.BlockTouchType.Tutorial);
            failCallback?.Invoke("bldgData is null");
            yield break;
        }

        TerritorySNGControl._inst.ShowSNGBldgMenuUI(bldgData.TerritorySNGBldg.gameObject, true);
        UISNGBldgMenu menu = UIManager.Instance.GetFloatingUI<UISNGBldgMenu>();
        if(menu)
            menu._isCloseOnMove = false;
        yield return null;
        yield return null;
    }
}

[System.Serializable]
[InfoBox("건물 메뉴 버튼 클릭")]
public class BldgMenuTutorialData : AbsHoleTutorialData
{
    public override string GetComment()
    {
        return $"{ButtonType} 건물 메뉴 버튼 클릭";
    }
    
    public UISNGBldgMenu.BuildingMenuButtonType ButtonType;

    private Coroutine _checkKeepWaitingCoroutine;
    private int _buildingId;
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        UIManager.Instance.CloseAllPopupUI();
        UISNGBldgMenu menu = null;
        yield return new WaitUntilWithTimeout(() =>
        {
            menu = UIManager.Instance.GetFloatingUI<UISNGBldgMenu>();
            return menu != null;
        }, 10f);
        if (menu == null)
        {
            failCallback?.Invoke("UISNGBldgMenu is null");
            yield break;
        }

        menu._isCloseOnMove = false;

        _buildingId = menu.BuildingID;

        var target = menu.GetBuildingMenuButton(ButtonType);
        if (target != null)
        {
            if(ButtonType == UISNGBldgMenu.BuildingMenuButtonType.Accel)
                _checkKeepWaitingCoroutine = CoroutineManager.Instance.StartCoroutine(CheckKeepWaiting());
            yield return OpenTutorialHole(target);
        }
        else
        {
            failCallback?.Invoke($"{ButtonType} target not found");
            yield break;
        }
        if (_checkKeepWaitingCoroutine != null)
        {
            CoroutineManager.Instance.StopCoroutine(_checkKeepWaitingCoroutine);
        }
      
        if (ButtonType == UISNGBldgMenu.BuildingMenuButtonType.BuildMode_Confirm)
        {
            //건물이 생길때까지 대기
            yield return new WaitUntil(() => CheckBuilding(_buildingId));
        }
    }

    private bool CheckBuilding(int buildingId)
    {
        foreach (var building in TerritorySNGControl._inst._dictMyTerritoryAllBuilding)
        {
            if (building.Value.BldgData._buildingID == buildingId)
            {
                return true;
            }
        }
        return false;
    }

    //가속버튼 누르라고 하는 경우 시간이 다되면 UISNGBldgMenu가 없어진다
    private IEnumerator CheckKeepWaiting()
    {
        yield return new WaitUntil(() => UIManager.Instance.GetFloatingUI<UISNGBldgMenu>() == null);
        _isHoleClick = true;
        _checkKeepWaitingCoroutine = null;
    }
}

[System.Serializable]
[InfoBox("건물 풍선 이 특정 상태가 될때까지 대기")]
public class BldgCompleteTutorialData : AbsTutorialData
{
    public override string GetComment()
    {
        return $"{BuildingType} 건물 풍선 이 {UIBldgState} 상태가 될때까지 대기";
    }
    
    public PEnumModelProtoEnumrefBuildingTypeWrapper.Types.PEnumModelProtoEnumrefBuildingType BuildingType;

    public UISNGBldgState.UIBldgState UIBldgState;

    public int TimeOutSec = 30;

    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        TerritoryBldgData bldgData =
            TerritorySNGControl._inst._myBldgInfos.Values.FirstOrDefault(bldg =>
                bldg._buildingType == BuildingType);

        if (bldgData == null)
        {
            failCallback?.Invoke("bldgData is null");
            yield break;
        }
        UIManager.Instance.BlockTouch(99, UIManager.BlockTouchType.Tutorial);
        TerritoryCameraMoveTutorialData territoryCameraMoveTutorialData = new();
        territoryCameraMoveTutorialData.BuildingType = BuildingType;
        yield return territoryCameraMoveTutorialData.Process(null);
        
        var waitUntilWithTimeout = new WaitUntilWithTimeout(() =>
            bldgData.TerritorySNGBldg.BldgStateData._uiState.IsSetBldgState(UIBldgState), 30);
        yield return waitUntilWithTimeout;
        if (waitUntilWithTimeout.IsTimeout)
        {
            failCallback?.Invoke("Timeout");
        }
    }
}
[InfoBox("건물 풍선이 특정상태가 될때까지 대기후 풍선 클릭 유도")]
public class BldgStateUITutorialData : AbsHoleTutorialData
{
    public override string GetComment()
    {
        return $"{BuildingType} 건물 풍선이 {UIBldgState}상태가 될때까지 대기후 풍선 클릭 유도";
    }
    public PEnumModelProtoEnumrefBuildingTypeWrapper.Types.PEnumModelProtoEnumrefBuildingType BuildingType;

    public UISNGBldgState.UIBldgState UIBldgState = UISNGBldgState.UIBldgState.Complete;
    public UISNGBldgState.UIBldgState SkipUIBldgState = UISNGBldgState.UIBldgState.None;

    private Coroutine _openTutorialHoleCoroutine;
    private Coroutine _skipConditionCoroutine;

    private bool _isConditionMatch = false;

    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        _isConditionMatch = false;
        TerritoryBldgData bldgData =
            TerritorySNGControl._inst._myBldgInfos.Values.FirstOrDefault(bldg =>
                bldg._buildingType == BuildingType);

        if (bldgData == null)
        {
            UIManager.Instance.ReleaseTouch(UIManager.BlockTouchType.Tutorial);
            failCallback.Invoke("bldgData is null");
            yield break;
        }

        yield return CheckCondition(bldgData);
        if (_isConditionMatch == false)
        {
            failCallback.Invoke("Condition Fail");
            yield break;
        }
        //버튼을 리스트에 담아서 리턴하고 그중에 활성화 되어있는것을 가리킴
        RectTransform target = bldgData.TerritorySNGBldg.BldgStateUI.GetCurrentStateButton();
        if (target == null)
        {
            failCallback.Invoke("BldgStateUI Target is null");
            yield break;
        }

        TerritoryCameraMoveTutorialData territoryCameraMoveTutorialData = new();
        territoryCameraMoveTutorialData.BuildingType = BuildingType;
        yield return territoryCameraMoveTutorialData.Process(null);
        _openTutorialHoleCoroutine = CoroutineManager.Instance.StartCoroutine(OpenTutorialHole(target));
        _skipConditionCoroutine = CoroutineManager.Instance.StartCoroutine(CheckSkipCondition(bldgData));
        
        yield return new WaitUntil(() => _openTutorialHoleCoroutine == null || _skipConditionCoroutine == null);
        
        if (_openTutorialHoleCoroutine != null)
        {
            CoroutineManager.Instance.StopCoroutine(_openTutorialHoleCoroutine);
        }

        if (_skipConditionCoroutine != null)
        {
            CoroutineManager.Instance.StopCoroutine(_skipConditionCoroutine);
        }
        _openTutorialHoleCoroutine = null;
        _skipConditionCoroutine = null;
        //서버에서 응답을 받아 스킵 조건이 될때가지 대기, 건물 언락은 팝업이 뜨기 때문에 예외처리함
        if(UIBldgState != UISNGBldgState.UIBldgState.CanBldgUnlock)
            yield return CheckSkipCondition(bldgData);
    }

    private IEnumerator CheckCondition(TerritoryBldgData bldgData)
    {
        long endTime = TimeUtil.UnixTimestampFromDateTime(TimeUtil.ServerUtcNow.AddSeconds(10));
        _isConditionMatch = false;
        UIManager.Instance.BlockTouch(99, UIManager.BlockTouchType.Tutorial);
        while (TimeUtil.GetNowTimestamp() < endTime)
        {
            if (IsSkipCondition(bldgData) || (bldgData.TerritorySNGBldg.IsNullBlsdStateUI() == false && bldgData.TerritorySNGBldg.BldgStateData.IsSetBldgState(UIBldgState)))
            {
                _isConditionMatch = true;
                //다음 프레임에 ui를 갱신하기 때문
                yield return null;
                break;
            }
            yield return new WaitForSeconds(0.3f);
        }
        UIManager.Instance.ReleaseTouch(UIManager.BlockTouchType.Tutorial);
    }

    private IEnumerator CheckSkipCondition(TerritoryBldgData bldgData)
    {
        yield return new WaitUntil(() => IsSkipCondition(bldgData));
        _skipConditionCoroutine = null;
    }

    private bool IsSkipCondition(TerritoryBldgData bldgData)
    {
        if (SkipUIBldgState == UISNGBldgState.UIBldgState.None)
        {
            return bldgData.TerritorySNGBldg.BldgStateData._uiState == UISNGBldgState.UIBldgState.None;
        }
        else
        {
            return bldgData.TerritorySNGBldg.IsNullBlsdStateUI() == false &&
                                             bldgData.TerritorySNGBldg.BldgStateData.IsSetBldgState(SkipUIBldgState);    
        }
    }

    protected override IEnumerator OpenTutorialHole(RectTransform rectTrans)
    {
        yield return base.OpenTutorialHole(rectTrans);
        _openTutorialHoleCoroutine = null;
    }
}

//가속의 경우 시간이 지나서 가속이 불가능해질수 있어서 팝업이 닫히면 완료 처리가 필요하다.
[InfoBox("충전 팝업")]
public class RechargeAccelPopupTutorialData : AbsHoleTutorialData
{
    public override string GetComment()
    {
        return $"{BuildingType} {AccelType} 충전 팝업";
    }
    public PEnumModelProtoEnumrefBuildingTypeWrapper.Types.PEnumModelProtoEnumrefBuildingType BuildingType;

    public enum RechargeAccelType
    {
        Building,
        Action
    }

    public RechargeAccelType AccelType = RechargeAccelType.Action;

    [OnValueChanged("OnTargetInfoChange")] public ScrollTargetInfo TargetInfo;

    private Coroutine _checkConditionCoroutine;
    private GameObject _prefab;

    public void OnTargetInfoChange()
    {
        if (_prefab == null)
        {
            _prefab = Util.LoadRes<GameObject>("UI/Item/RechargePopup");
        }

        if (TargetInfo != null)
        {
            TargetInfo.OnChangePopupPrefab(_prefab);
        }

        _prefab = null;
    }

    [Button("LoadPrefab", ButtonSizes.Small)]
    private void LoadPrefab()
    {
        OnTargetInfoChange();
    }


    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        //해당 타입의 건물을 찾는다 동일 타입의 건물이 여러개인 경우가 있음
        List<TerritoryBldgData> bldgDatas = new List<TerritoryBldgData>();
        foreach (var bldgInfo in TerritorySNGControl._inst._myBldgInfos)
        {
            if (bldgInfo.Value._buildingType != BuildingType)
                continue;
            bldgDatas.Add(bldgInfo.Value);
        }

        PBuildingStateEnum.Types.PBuildingState buildingState = AccelType == RechargeAccelType.Action
            ? PBuildingStateEnum.Types.PBuildingState.Action
            : PBuildingStateEnum.Types.PBuildingState.Build;

        var findBldgData = bldgDatas.Find(e => e._state == buildingState);
        if (findBldgData == null)
        {
            failCallback.Invoke("bldgData is null");
            yield break;
        }
        if (findBldgData._stateUpAt <= TimeUtil.GetNowTimestamp())
        {
            if (findBldgData.TerritorySNGBldg.BldgStateData.IsSetBldgState(UISNGBldgState.UIBldgState.Complete))
            {
                BldgStateUITutorialData clickComplete = new BldgStateUITutorialData()
                {
                    BuildingType = BuildingType,
                    UIBldgState = UISNGBldgState.UIBldgState.Complete,
                    SkipUIBldgState = UISNGBldgState.UIBldgState.None
                };
                yield return clickComplete.Process(null);
            }
            yield break;
        }

        var rechargePopup = UIManager.Instance.GetPopupUIFromList<UIRechargePopup>();
        if (rechargePopup == null)
        {
            rechargePopup = UIManager.Instance.OpenUI<UIRechargePopup>("UI/Item/RechargePopup");
            rechargePopup.RechargeAccel(findBldgData._playerBuildingID);
        }

        var targetGetter = rechargePopup.GetComponent<TutorialHoleScrollTargetGetter>();
        if (targetGetter == null)
        {
            failCallback.Invoke("targetGetter is null");
            yield break;
        }

        RectTransform target =
            targetGetter.GetTarget(TargetInfo.ScrollId, TargetInfo.SlotIndex, TargetInfo.HoleTargetId);

        _checkConditionCoroutine = CoroutineManager.Instance.StartCoroutine(CheckCondition(findBldgData));
        yield return OpenTutorialHole(target);
        if (_checkConditionCoroutine != null)
        {
            CoroutineManager.Instance.StopCoroutine(_checkConditionCoroutine);
        }
    }

    private IEnumerator CheckCondition(TerritoryBldgData bldgData)
    {
        //stateUp 시간이 지났다면 해당 튜토리얼 종료
        yield return new WaitUntil(() => bldgData._stateUpAt <= TimeUtil.GetNowTimestamp());
        //풍선 처리 시간이 있어서 0.1초 정도 대기한다.
        yield return new WaitForSeconds(0.1f);
        if (bldgData.TerritorySNGBldg.BldgStateData.IsSetBldgState(UISNGBldgState.UIBldgState.Complete))
        {
            BldgStateUITutorialData clickComplete = new BldgStateUITutorialData()
            {
                BuildingType = BuildingType,
                UIBldgState = UISNGBldgState.UIBldgState.Complete,
                SkipUIBldgState = UISNGBldgState.UIBldgState.None
            };
            yield return clickComplete.Process(null);
        }
        _isHoleClick = true;
        _checkConditionCoroutine = null;
    }
}
[InfoBox("스테이지 시작 대기")]
public class WaitingForStageStart : AbsTutorialData
{
    public override string GetComment()
    {
        return $"스테이지 시작 대기";
    }
    public int TimeoutSec = 10;
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        var uiStageStart = UIManager.Instance.GetPopupUIFromList<UIStageStart>();
        var waitUntil = new WaitUntilWithTimeout(() => uiStageStart == null, TimeoutSec);
        yield return waitUntil;
        if (waitUntil.IsTimeout)
            failCallback.Invoke("Timeout");
    }
}

public class QTETutorialData : AbsTutorialData
{
    public override string GetComment()
    {
        return $"{QTEType} Tutorial";
    }
    public enum QuickTimeEventType
    {
        QTE1,
        QTE2,
    }

    public QuickTimeEventType QTEType;
    private AbsUITutorialQuickTimeEvent _quickTimeEvent;
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        UIManager.Instance.ReleaseTouch(UIManager.BlockTouchType.Tutorial);
        UIManager.Instance.CloseAllPopupUI();
        if (QTEType == QuickTimeEventType.QTE1)
        {
            _quickTimeEvent =
                UIManager.Instance.OpenUI<UITutorialQuickTimeEvent>("UI/Tutorial/UITutorialQuickTimeEvent");
        }
        else if (QTEType == QuickTimeEventType.QTE2)
        {
            _quickTimeEvent =
                UIManager.Instance.OpenUI<UITutorialQuickTimeEvent2>("UI/Tutorial/UITutorialQuickTimeEvent02");
        }

        yield return new WaitUntil(() => _quickTimeEvent == null);
        
    }

    public IEnumerator ForceEnd()
    {
        _quickTimeEvent.WaitClose = true;
        _quickTimeEvent.CloseUI();
        yield break;
    }
}
// [InfoBox("패킷 응답 대기")]//리커넥션이 일어나면 감지할수가 없기 때문에 사용에 주의해야 한다.
// public class ResPacketChecker : AbsTutorialData
// {
//     public override string GetComment()
//     {
//         return $"{ResPacketType} 패킷 응답 대기";
//     }
//     [ValueDropdown("GetTypes")]
//     public PResDefineEnum.Types.PResDefine ResPacketType;
//
//     public int TimeOutSeconds = 30;
//
//     private static IEnumerable GetTypes = new ValueDropdownList<PResDefineEnum.Types.PResDefine>()
//     {
//         { "[출정창 팝업 유닛 배치 응답] ResWorldUnitDeployTo", PResDefineEnum.Types.PResDefine.ResWorldUnitDeployTo },
//         { "[출정창 팝업 응답] ResArmyPresetInfo", PResDefineEnum.Types.PResDefine.ResArmyPresetInfo },
//     };
//
//     private bool _isReceivePacket = false;
//     public override IEnumerator Process(UnityAction<string> failCallback)
//     {
//         _isReceivePacket = false;
//         UIManager.Instance.BlockTouch(30, UIManager.BlockTouchType.Tutorial);
//         GlobalEventRouter.Instance.OnPacketReceive.Register(OnPacketReceive);
//         var waitUntilWithTimeout = new WaitUntilWithTimeout(() => _isReceivePacket, 30);
//         yield return waitUntilWithTimeout;
//         GlobalEventRouter.Instance.OnPacketReceive.UnRegister(OnPacketReceive);
//         if (waitUntilWithTimeout.IsTimeout)
//         {
//             failCallback?.Invoke("Timeout");
//         }
//         UIManager.Instance.ReleaseTouch(UIManager.BlockTouchType.Tutorial);
//     }
//
//     private void OnPacketReceive(PResponse response)
//     {
//         if (response.Id == ResPacketType)
//         {
//             _isReceivePacket = true;
//             Debug.LogWarning($"[ResPacketChecker] {response.Id}");
//         }
//     }
// }
[InfoBox("패킷 블락 처리")]
public class PacketBlocker : AbsTutorialData
{
    public override string GetComment()
    {
        return $"{ReqPacketType} 패킷 블락";
    }
    [ValueDropdown("GetTypes")]
    public PReqDefineEnum.Types.PReqDefine ReqPacketType;

    private static IEnumerable GetTypes = new ValueDropdownList<PReqDefineEnum.Types.PReqDefine>()
    {
        { "[타이탄 격납고 언락] ReqTitanBarrackUnlock", PReqDefineEnum.Types.PReqDefine.ReqTitanBarrackUnlock },
    };

    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        TcpClientManager.Instance.AddBlockRequest(ReqPacketType);
        yield break;
    }
}
[InfoBox("패킷 블락 해제")]
public class PacketBlockRelease : AbsTutorialData
{
    public override string GetComment()
    {
        return $"{ReqPacketType} 패킷 블락 해제";
    }
    [ValueDropdown("GetTypes")]
    public PReqDefineEnum.Types.PReqDefine ReqPacketType;

    private static IEnumerable GetTypes = new ValueDropdownList<PReqDefineEnum.Types.PReqDefine>()
    {
        { "[타이탄 격납고 언락] ReqTitanBarrackUnlock", PReqDefineEnum.Types.PReqDefine.ReqTitanBarrackUnlock },
    };

    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        TcpClientManager.Instance.RemoveBlockRequest(ReqPacketType);
        yield break;
    }
}

[InfoBox("연맹가입 튜토리얼")]
//이건 모듈을 조합해서 만들기가 힘들어서 그냥 전용으로 만듬..여기서 모듈을 조합함
public class AllianceTutorialData : AbsTutorialData
{
    public override string GetComment()
    {
        return "연맹가입 튜토리얼";
    }
    [InfoBox("카메라 이동후 나올 스크립트")] 
    public ScriptTutorialData scriptTutorialData1;
    [InfoBox("빈땅 선택후 나올 스크립트")]
    public ScriptTutorialData scriptTutorialData2;
    
    private bool _isReceivePacket = false;
    private bool _isError = false;
    private Vector3 _cameraPos;
    private Vector3 _masterTargetPos;
    private UIWorldEmptyLand _worldEmptyLand;

    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        
        PReqAllianceWorldInfo packet = new PReqAllianceWorldInfo()
        {
            ReqTutorialPos = true,
        };
        TcpClientManager.Instance.SendMain(PReqDefineEnum.Types.PReqDefine.ReqAllianceWorldInfo, packet, ReceiveAllianceWorldInfo);
        
        if (MainControl.CurrentMode == MainControl.Mode.Territory)
        {
            WaitingForChangeModeTutorialData enterWorld = new WaitingForChangeModeTutorialData()
            {
                Mode = MainControl.Mode.World
            };
            TerritorySNGControl._inst.EnterWorld();
            yield return enterWorld.Process(null);
        }
        var waitUntilWithTimeout = new WaitUntilWithTimeout(() => _isReceivePacket);
        yield return waitUntilWithTimeout;
        if (_isError || waitUntilWithTimeout.IsTimeout)
        {
            failCallback?.Invoke($"isError : {_isError}, IsTimeout : {waitUntilWithTimeout.IsTimeout}");
            yield break;
        }
        WorldControl._inst.AutoScrollZoomCamera(_cameraPos, WorldControl.CameraDistance);
        
        yield return new WaitUntil(() => WorldControl._inst.IsArriveAutoCamera());

        if (scriptTutorialData1 != null)
            yield return scriptTutorialData1.Process(null);
        //빈땅 선택
        yield return AllianceMasterTarget(_masterTargetPos);
        SelectEmptyLand(_masterTargetPos);
        
        if (scriptTutorialData2 != null)
            yield return scriptTutorialData2.Process(null);
        
        if(_worldEmptyLand != null)
            _worldEmptyLand.OnMoveCastleForTutorial();
    }

    public override IEnumerator PostProcess()
    {
        _worldEmptyLand = null;
        _isReceivePacket = false;
        _isError = false;
        _cameraPos = Vector3.negativeInfinity;
        _masterTargetPos = Vector3.negativeInfinity;
        yield return base.PostProcess();
    }

    private void ReceiveAllianceWorldInfo(PResponse response)
    {
        _isReceivePacket = true;
        _isError = Util.CheckError(response) == false;
        
        if (_isError)
            return;
        
        
        PResAllianceWorldInfo pData = response.GetData<PResAllianceWorldInfo>();
        // 데이터 없을 예외처리. 영주성으로 옮긴다.
        if (pData.TutorialPos != null)
        {
            //  연맹 튜토리얼 위치 정보 (1.지휘본부 근처 2.연맹장 주변 근처 3.연맹장이 없을 경우는 유저위치 리턴)
            // 서버에서 받아온 좌표로 이동시킨다.
            _cameraPos = new Vector3(pData.TutorialPos.X, 0f, pData.TutorialPos.Y);
            _masterTargetPos = new Vector3(pData.TutorialPos.X, 0f, pData.TutorialPos.Y);
        }
        else
        {
            // 영주성 좌표로 이동시킨다.
            //기존 영주성 좌표로 이동시에는 영주성 옆에 이동 시켜야하므로 addPosX - 2.5f 해줌
            _cameraPos = new Vector3(pData.MasterCastlePos.X -2.5f, 0f, pData.MasterCastlePos.Y);
            _masterTargetPos = new Vector3(pData.MasterCastlePos.X, 0f, pData.MasterCastlePos.Y);
        }
        
    }
    private IEnumerator AllianceMasterTarget(Vector3 position)
    {
        SetActiveHud(true);

        yield return new WaitForSeconds(0.2f);
            

        WorldBldgBase pickedDestObject = WorldRoomManager.Instance.PickBldg(position);
        if (pickedDestObject != null)
        {
            if (UISearchArrow._inst)
                UISearchArrow._inst.Show(pickedDestObject.transform);
        }
    }
    private void SetActiveHud(bool state)
    {
        if (MainControl._inst)
            MainControl._inst.ShowHudUI(state);

        if (state) 
            return;
        Canvas canvas = UIManager.FieldCanvasTransform.GetComponent<Canvas>();
        if (canvas != null)
            canvas.enabled = true;
    }

    private void SelectEmptyLand(Vector3 targetPos)
    {
        _worldEmptyLand = UIManager.Instance.OpenUI<UIWorldEmptyLand>("UI/World/Bldg/UIWorldBldgEmpty");
        if (_worldEmptyLand == null)
        {
            return;
        }
        _worldEmptyLand.SetInfo(null);
        _worldEmptyLand.SetPos(targetPos, 0.5f, WorldControl.CameraLookAtPos);

        RectTransform rt = Util.GetComponent<RectTransform>(_worldEmptyLand.gameObject, "Popup");

        if(rt != null)
        {
            rt.SetActive(false);

            rt = Util.GetComponent<RectTransform>(_worldEmptyLand.gameObject, "ArrowIcon");

            if (rt != null)
                rt.SetActive(false);
        }
    
    }
}

[InfoBox("HUD 활성화 여부 설정")]
public class ActiveHUDTutorialData : AbsTutorialData
{
    public override string GetComment()
    {
        return IsActive ? "HUD 활성화" : "HUD 비활성화";
    }
    public bool IsActive;
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        TutorialStepManager.Instance.SetActiveHud(IsActive);
        yield break;
    }
}

[InfoBox("건물 풍선 가리기 설정")]
public class HideBalloonTutorialData : AbsTutorialData
{
    public override string GetComment()
    {
        return IsHide ? "건물 풍선 가리기" : "건물 풍선 보이기";
    }
    public bool IsHide = true;
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        TutorialStepManager.Instance.SetBalloonHide(IsHide);
        yield break;
    }
}
[InfoBox("튜토리얼용 건물 이펙트 보여주기")]
public class ShowBldgTutorialEffect : AbsTutorialData
{
    public override string GetComment()
    {
        return $"{BuildingType} 이펙트 ON";
    }
    public float WaitSeconds = 3f;

    public PEnumModelProtoEnumrefBuildingTypeWrapper.Types.PEnumModelProtoEnumrefBuildingType BuildingType =
        PEnumModelProtoEnumrefBuildingTypeWrapper.Types.PEnumModelProtoEnumrefBuildingType.Pub;
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        TerritoryBldgData bldgData =
            TerritorySNGControl._inst._myBldgInfos.Values.FirstOrDefault(bldg =>
                bldg._buildingType == BuildingType);
        if (bldgData == null || bldgData.BldgController == null)
        {
            failCallback?.Invoke($"bldgData or BldgController is null");
            yield break;
        }
        UIManager.Instance.BlockTouch(99, UIManager.BlockTouchType.Tutorial);
        if (bldgData._owner.TryGetComponent<BackgroundLoadingComponent>(out _))
        {
            yield return new WaitUntil(() => bldgData.TerritorySNGBldg.IsInitedFromBGLoadComponent);
        }
        var effectController = bldgData._owner.GetComponent<TerritorySNGBldgTutorialEffectController>();
        if (effectController != null)
        {
            effectController.ShowEffect();
            yield return new WaitForSeconds(WaitSeconds);
        }
        UIManager.Instance.ReleaseTouch(UIManager.BlockTouchType.Tutorial);
    }
}
[InfoBox("튜토리얼용 건물 이펙트 끄기")]
public class HideBldgTutorialEffect : AbsTutorialData
{
    public override string GetComment()
    {
        return $"{BuildingType} 이펙트 OFF";
    }
    public PEnumModelProtoEnumrefBuildingTypeWrapper.Types.PEnumModelProtoEnumrefBuildingType BuildingType =
        PEnumModelProtoEnumrefBuildingTypeWrapper.Types.PEnumModelProtoEnumrefBuildingType.Pub;
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        TerritoryBldgData bldgData =
            TerritorySNGControl._inst._myBldgInfos.Values.FirstOrDefault(bldg =>
                bldg._buildingType == BuildingType);
        if (bldgData == null || bldgData.BldgController == null)
        {
            failCallback?.Invoke($"bldgData or BldgController is null");
            yield break;
        }

        var effectController = bldgData._owner.GetComponent<TerritorySNGBldgTutorialEffectController>();
        if (effectController != null)
        {
            effectController.HideEffect();
        }
    }
}


[InfoBox("영웅 인벤토리에서 특정 영웅 선택하기")]
public class SelectHeroInventory : AbsTutorialData
{
    public override string GetComment()
    {
        return $"영웅 인벤토리에서 {HeroId} 영웅 선택하기";
    }
    public int HeroId;

    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        var heroId = HeroId;
        if (Player._playerHeroes.ContainsKey(heroId) == false)
        {
            heroId = Player._playerHeroes.First().Key;
        }
        var popup = UIManager.Instance.GetPopupUIFromList<UIHeroInventory>();
        if (popup == null)
        {
            popup = UIHeroInventory.Open();
        }
        popup.SetToggleHero(heroId);
        yield break;
    }
}

public class SetTutorialTargetMonsterId : AbsTutorialData
{
    //준비버튼을 눌렀을때
    public override string GetComment()
    {
        return "";
    }
    public int MonsterId;
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        TroopManager.Instance.TroopPicker.TutorialTargetMonsterId = MonsterId;
        yield break;
    }
}
[InfoBox("모든 UI닫기")]
public class CloseAllUI : AbsTutorialData
{
    public override string GetComment()
    {
        return "";
    }
    public bool IsPopupOnly = false;
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        if (IsPopupOnly)
            UIManager.Instance.CloseAllPopupUI();
        else
            UIManager.Instance.CloseAllUI();
        yield break;
    }
}
[InfoBox("컨텐츠 오픈 팝업 열기(보여줄게 있다면)")]
public class ShowContentsOpenPopup : AbsTutorialData
{
    public override string GetComment()
    {
        return "컨텐츠 오픈 팝업 열기";
    }
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        var isOpen = FunctionLockManager.Instance.CheckOpenPopup(PEnumModelProtoEnumrefUnlockSettingWrapper.Types.PEnumModelProtoEnumrefUnlockSetting.Chapter, MissionManager.Instance.CurrentChapterID - 1);
        if (!isOpen) 
            yield break;
        UIManager.Instance.ReleaseTouch(UIManager.BlockTouchType.Tutorial);
        while (true)
        {
            yield return new WaitForSeconds(0.3f);
            var contentsPopup = UIManager.Instance.GetPopupUIFromList<UIContentsOpenPopup>();
            if (contentsPopup == null)
            {
                break;
            }
        }
    }
}

[InfoBox("파괴된 영지 수리 연출")]
public class ChangeTerritoryBackground : AbsTutorialData
{
    public override string GetComment()
    {
        return "파괴된 영지 수리 연출";
    }
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        if (TerritorySNGControl._inst.TerritoryBaseObjectBgController == null)
        {
            failCallback?.Invoke($"TerritoryBaseObjectBgController is null");
            yield break;
        }
        yield return TerritorySNGControl._inst.TerritoryBaseObjectBgController.ChangeTerritoryBackground();
    }
}

public class PlaySound : AbsTutorialData
{
    public override string GetComment()
    {
        return "";
    }
    public int SoundId;
    public float Delay;
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        SoundManager.Instance.PlaySound(SoundId, Delay);
        yield break;
    }
}
[InfoBox("존 스테이지 시작")]
public class ZoneStageStartTutorialData : AbsTutorialData
{
    public override string GetComment()
    {
        return "존 스테이지 시작";
    }
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        if (ZoneStageManager.Status != ZoneStageStatus.Start)
        {
            failCallback?.Invoke($"ZoneStageStatus is not Start. : {ZoneStageManager.Status}");
            yield break;
        }
        //ZoneStageManager.Instance.RequestStageStart();
        ZoneStageManager.Instance.RequestStageStart();
        TroopManager.Instance.TroopPicker.ActTutorialEnd = null;
        TroopManager.Instance.TroopPicker.TutorialTargetMonsterId = -1;
    }
}

public class LordSkillGetPopupTutorialData : AbsHoleTutorialData
{
    private GameObject _prefab;
    
    [ShowInInspector, TypeFilter("GetFilteredTypeList")] [OnValueChanged("OnTargetInfoChange"), InlineButton("Reload")]
    public AbsTargetInfo TargetInfo;
    public void OnTargetInfoChange()
    {
        Reload();
    }  
    private void Reload()
    {
        if (_prefab == null)
        {
            _prefab = Util.LoadRes<GameObject>(UILordSkillAcquirePopup.PrefabPath);
        }

        if (TargetInfo != null)
        {
            TargetInfo.OnChangePopupPrefab(_prefab);
        }

        _prefab = null;
    }

    private static IEnumerable<Type> _filteredTypeList;

    public IEnumerable<Type> GetFilteredTypeList()
    {
        if (_filteredTypeList == null)
        {
            _filteredTypeList = typeof(AbsTargetInfo).Assembly.GetTypes()
                .Where(x => !x.IsAbstract) // Excludes BaseClass
                .Where(x => !x.IsGenericTypeDefinition) // Excludes C1<>
                .Where(x => typeof(AbsTargetInfo)
                    .IsAssignableFrom(x)); // Excludes classes not inheriting from BaseClass    
        }

        return _filteredTypeList;
    }
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        //새로 얻은 영주 스킬이 있는지 확인
        var lordSkillSettingPopup = UIManager.Instance.GetPopupUIFromList<UIMainLordSkillSettingPopup>();
        if (lordSkillSettingPopup == null)
        {
            failCallback?.Invoke("UIMainLordSkillSettingPopup not found.");
            yield break;
        }
        var waitUntilWithTimeout = new WaitUntilWithTimeout(()=> lordSkillSettingPopup.IsReceiveNewList, 10f);
        yield return waitUntilWithTimeout;
        if (waitUntilWithTimeout.IsTimeout)
        {
            failCallback?.Invoke("Timeout");
            yield break;
        }

        var acquirePopup =  UIManager.Instance.GetPopupUIFromList<UILordSkillAcquirePopup>();
        if (acquirePopup == null)
        {
            yield break;
        }
        RectTransform holeTarget = null;
        switch (TargetInfo)
        {
            case FixedTargetInfo fixedTargetInfo:
            {
                var getter = acquirePopup.GetComponent<TutorialHoleFixedTargetGetter>();
                holeTarget = getter.GetTarget(fixedTargetInfo.HoleTargetId);
                break;
            }
            case ScrollTargetInfo scrollTargetInfo:
            {
                var getter = acquirePopup.GetComponent<TutorialHoleScrollTargetGetter>();
                holeTarget = getter.GetTarget(scrollTargetInfo.ScrollId, scrollTargetInfo.SlotIndex,
                    scrollTargetInfo.HoleTargetId);
                break;
            }
            case EnhancedScrollTargetInfo enhancedScrollTargetInfo:
            {
                var getter = acquirePopup.GetComponent<TutorialHoleEnhancedScrollTargetGetter>();
                holeTarget = getter.GetTarget(enhancedScrollTargetInfo.ScrollId,
                    enhancedScrollTargetInfo.DataIndex, enhancedScrollTargetInfo.HoleTargetId);
                break;
            }
        }
        

        if (holeTarget != null)
        {
            var button = holeTarget.GetComponent<Button>();
            if (holeTarget.gameObject.activeInHierarchy == false || (button != null && button.enabled == false))
            {
                yield return new WaitUntilWithTimeout(() => holeTarget == null || button == null  || (holeTarget.gameObject.activeInHierarchy && button.enabled), 5f);
            }
            yield return OpenTutorialHole(holeTarget);
        }
    }

    public override string GetComment()
    {
        return "영주 스킬 획득 팝업";
    }
}

public class SendSLog : AbsTutorialData
{
    public int FunnelType;
    public int FunnelSubType;
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        if (FunnelType == 0 || FunnelSubType == 0)
        {
            failCallback?.Invoke($"Invalid FunnelType {FunnelType}, {FunnelSubType}");
            yield break;
        }
        NetmarbleSDKManager.Instance.SendLog(FunnelType, FunnelSubType);
    }
    public override string GetComment()
    {
        return $"SLog ({FunnelType}|{FunnelSubType})";
    }
}
public class SendEventLogger : AbsTutorialData
{
    [ValueDropdown("GetTypes")] public EventLogger.LogEvent LogEvent;

    private static IEnumerable GetTypes = new ValueDropdownList<EventLogger.LogEvent>()
    {
        EventLogger.LogEvent.tutorial_complete,
        EventLogger.LogEvent.funnel_first,
    };
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        if (LogEvent == EventLogger.LogEvent.none)
        {
            failCallback?.Invoke($"Invalid LogEventType {LogEvent}");
            yield break;
        }
        EventLogger.MarketingEvent(LogEvent);
        EventLogger.FirebaseAnalyticsEvent(LogEvent);
    }

    public override string GetComment()
    {
        return $"LogEvent {LogEvent}";
    }
}





public static class Helper
{
    public static bool IsZoneOpen(int zoneId)
    {
        var zoneIndexList = TerritoryZoneInfo.Instance.GetZoneIdToIndexList(zoneId);

        if (zoneIndexList == null)
        {
            return false;
        }

        for (int i = 0; i < zoneIndexList.Count; ++i)
        {
            int zoneIndex = zoneIndexList[i];
            int zoneTileId = TerritoryUtil.GetIdByOffset(TerritoryUtil.GetZoneOffsetByZoneID(zoneIndex));
            if (TerritorySNGControl._inst._listOpenZoneTileId.Contains(zoneTileId) == false)
            {
                return false;
            }
        }

        return true;
    }

    public static IEnumerator WaitForActiveTutorialHole(RectTransform holeTarget)
    {
        if (holeTarget == null) 
            yield break;
        var button = holeTarget.GetComponent<Button>();
        if (holeTarget.gameObject.activeInHierarchy == false || (button != null && button.enabled == false))
        {
            Debug.Log($"waiting for active holtTarget");
            yield return new WaitUntilWithTimeout(() => holeTarget.gameObject.activeInHierarchy && (button == null || button.enabled));
        }
    }
}
