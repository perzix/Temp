﻿using System.Collections.Generic;
using System.Linq;
using Sirenix.OdinInspector;
using UnityEngine;
using UnityEngine.UI;

[TypeInfoBox("일반적인 Scroll에서 사용함")]
public class TutorialHoleScrollTargetGetter : AbsTutorialHoleTargetGetter
{
    [System.Serializable]
    public class TargetInfo : AbsTutorialHoleTargetGetter.AbsTargetInfo
    {
        [SerializeField] public ScrollRect ScrollRect;
        [SerializeField] public GameObject SlotPrefab;
        public override void GenerateId()
        {
            if (ScrollRect == null || ScrollRect.content == null)
            {
                return;
            }

            var transform = ScrollRect.content.transform;
            while (true)
            {
                if (transform.TryGetComponent<TutorialHoleScrollTargetGetter>(out _))
                {
                    break;
                }

                transform = transform.parent;
            }

            TutorialHoleId = $"{transform.name}.{ScrollRect.name}";
        }
    }

    [SerializeField] private List<TargetInfo> _targetInfos = new List<TargetInfo>();

    public override List<string> GetIds()
    {
        return _targetInfos.Select(e => e.TutorialHoleId).ToList();
    }

    public List<string> GetSlotElementIds(string scrollId)
    {
        var find = _targetInfos.Find(e => e.TutorialHoleId == scrollId);
        if (find == null || find.SlotPrefab == null)
        {
            return null;
        }
        var getter = find.SlotPrefab.GetComponent<TutorialHoleScrollRectElementTargetGetter>();
        return getter != null ? getter.GetIds() : null;
    }

    public RectTransform GetTarget(string scrollerId, int slotIndex, string elementHoleId)
    {
        for (int i = 0; i < _targetInfos.Count; ++i)
        {
            var targetInfo =  _targetInfos[i];
            if (targetInfo.TutorialHoleId != scrollerId)
                continue;

            int slotCount = targetInfo.ScrollRect.content.childCount;
            if (slotIndex >= slotCount)
            {
                Debug.Log($"[TutorialHoleScrollTargetGetter][GetTarget] Invalid SlotIndex. [{scrollerId}/{slotIndex}/{elementHoleId}], SlotCount : {slotCount}");
                return null;
            }

            var slotObject = targetInfo.ScrollRect.content.GetChild(slotIndex);
            //slotObject.TryGetComponent<IUITutorialSlot>(out var slot)
            var getter = slotObject.GetComponent<TutorialHoleScrollRectElementTargetGetter>();
            return getter.GetTarget(elementHoleId);
        }
        Debug.Log($"[TutorialHoleScrollTargetGetter][GetTarget] Target Not Found. {scrollerId}/{slotIndex}/{elementHoleId}");
        return null;
    }
}

