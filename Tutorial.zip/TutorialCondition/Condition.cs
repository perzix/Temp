﻿namespace _02.Scripts.Tutorial.TutorialCondition
{
    public class Condition
    {
        
    }
}