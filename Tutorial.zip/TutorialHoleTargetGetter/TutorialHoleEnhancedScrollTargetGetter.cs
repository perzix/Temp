﻿using System.Collections.Generic;
using EnhancedUI.EnhancedScroller;
using UnityEngine;
using System.Linq;
public class TutorialHoleEnhancedScrollTargetGetter : AbsTutorialHoleTargetGetter
{
    [System.Serializable]
    public class TargetInfo : AbsTutorialHoleTargetGetter.AbsTargetInfo
    {
        [SerializeField] public EnhancedScroller EnhancedScroller;
        [SerializeField] public GameObject SlotPrefab;
        public override void GenerateId()
        {
            if (EnhancedScroller != null)
            {
                var transform = EnhancedScroller.transform;
                while (true)
                {
                    if (transform.TryGetComponent<TutorialHoleEnhancedScrollTargetGetter>(out _))
                    {
                        break;
                    }
                    transform = transform.parent;
                }
                TutorialHoleId = $"{transform.name}.{EnhancedScroller.name}"; 
            }
        }
    }
    [SerializeField]
    private List<TargetInfo> _targetInfos = new List<TargetInfo>();
    
    public override List<string> GetIds()
    {
        return _targetInfos.Select(e => e.TutorialHoleId).ToList();
    }
    public List<string> GetSlotElementIds(string scrollId)
    {
        var find = _targetInfos.Find(e => e.TutorialHoleId == scrollId);
        if (find == null || find.SlotPrefab == null)
        {
            return new List<string>();
        }
        var getter = find.SlotPrefab.GetComponent<TutorialHoleScrollRectElementTargetGetter>();
        return getter != null ? getter.GetIds() : new List<string>();
    }

    
    public RectTransform GetTarget(string scrollerId, int dataIndex, string elementHoleId)
    {
        if (string.IsNullOrEmpty(scrollerId) || string.IsNullOrEmpty(elementHoleId))
        {
            Debug.LogError($"[GetEnhancedScrollTarget][GetTarget] Invalid Param {scrollerId}/{dataIndex}/{elementHoleId}");
            return null;
        }
        
        for (int i = 0; i < _targetInfos.Count; ++i)
        {
            if ( _targetInfos[i].TutorialHoleId != scrollerId) 
                continue;

            _targetInfos[i].EnhancedScroller.JumpToDataIndex(dataIndex);
            var cellView = _targetInfos[i].EnhancedScroller.GetCellViewAtDataIndex(dataIndex);
            if (cellView == null)
            {
                Debug.Log($"[GetEnhancedScrollTarget][GetTarget] CellView is Null {scrollerId}/{dataIndex}/{elementHoleId}");
                return null;
            }

            var getter = cellView.GetComponent<TutorialHoleScrollRectElementTargetGetter>();
            return getter.GetTarget(elementHoleId);
        }
        Debug.Log($"[GetEnhancedScrollTarget][GetTarget] Target Not Found. {scrollerId}/{dataIndex}/{elementHoleId}");
        return null;
    }
}