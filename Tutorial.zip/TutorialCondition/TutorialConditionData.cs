﻿using System.Collections;
using System.Linq;
using Fun.Engine.Pb;
using Sirenix.OdinInspector;
using UnityEngine;

namespace TutorialCondition
{
    public abstract class AbsConditionData
    {
        protected bool _isConditionMatch;
        public virtual bool IsConditionMatch() => _isConditionMatch;
        public abstract IEnumerator CheckCondition();
    }

    public class NoneConditionData : AbsConditionData
    {
        public override bool IsConditionMatch()
        {
            return true;
        }

        public override IEnumerator CheckCondition()
        {
            yield break;
        }
    }

    public class MissionCondition : AbsConditionData
    {
        public int MissionId;
        
        public enum MissionType
        {
            ReceiveReward,
            Shortcut,
        }

        public MissionType Type = MissionType.ReceiveReward;

        public override IEnumerator CheckCondition()
        {
            _isConditionMatch = true;
            var modelMission = ModelMission.Instance.GetModel(MissionId);
            bool isMissionComplete = false;
            bool canReceiveReward = false;
            if (MissionManager.Instance.Chapter.TryGetValue(modelMission.CategoryId, out var missions) &&
                missions.TryGetValue(modelMission.MissionId, out var mission) && mission.Count >= mission.GetMaxCount())
            {
                isMissionComplete = true;
                canReceiveReward = mission.IsReward == false;
            }

            //미션 진행 튜토리얼인데 이미 미션을 완료 했으면 해당 튜토리얼 완료 처리 

            if (Type == MissionType.Shortcut && isMissionComplete)
            {
                _isConditionMatch = false;
            }
            else if (Type == MissionType.ReceiveReward && isMissionComplete &&
                     canReceiveReward == false) //보상 받기 튜토리얼인데 이미 보상을 받았으면 튜토리얼 완료 처리.
            {
                _isConditionMatch = false;
            }

            if (_isConditionMatch == false)
                Debug.Log($"[MissionCondition][CheckCondition] Condition Fail. {MissionId}/{Type}/IsMissionComplete : {isMissionComplete}/CanReceiveReward : {canReceiveReward}");

            yield break;
        }
    }
    [InfoBox("존 상태 체크")]
    public class ZoneCondition : AbsConditionData
    {
        public int ZoneId;
        public bool IsOpen;
        public override IEnumerator CheckCondition()
        {
            bool isZoneOpen = Helper.IsZoneOpen(ZoneId);
            _isConditionMatch = isZoneOpen == IsOpen;
            if (_isConditionMatch == false)
                Debug.Log($"[ZoneCondition] Condition Fail. {ZoneId}/{isZoneOpen}/{IsOpen}");
            yield break;
        }
    }

    public class BldgUnlockCondition : AbsConditionData
    {
        public PEnumModelProtoEnumrefBuildingTypeWrapper.Types.PEnumModelProtoEnumrefBuildingType BuildingType;
        public bool IsUnlock;

        public override IEnumerator CheckCondition()
        {
            _isConditionMatch = true;
            TerritoryBldgData bldgData =
                TerritorySNGControl._inst._myBldgInfos.Values.FirstOrDefault(bldg =>
                    bldg._buildingType == BuildingType);

            if (bldgData == null)
            {
                _isConditionMatch = false;
                Debug.Log($"[BldgUnlockCondition] Condition Fail. BldgData is null. {BuildingType}/{IsUnlock}");
                yield break;
            }

            if (IsUnlock)
                _isConditionMatch = bldgData._state != PBuildingStateEnum.Types.PBuildingState.Lock;
            else
                _isConditionMatch = bldgData._state == PBuildingStateEnum.Types.PBuildingState.Lock;
            
            if (_isConditionMatch == false)
                Debug.Log($"[BldgUnlockCondition] Condition Fail. {BuildingType}/{IsUnlock}/{bldgData._state}");
        }
    }
    [InfoBox("건물에 상태가 일치하면 진행")]
    public class BldgStateCondition : AbsConditionData
    {
        public PEnumModelProtoEnumrefBuildingTypeWrapper.Types.PEnumModelProtoEnumrefBuildingType BuildingType;
        public PBuildingStateEnum.Types.PBuildingState State;
        public bool NeedMatch;

        public override IEnumerator CheckCondition()
        {
            _isConditionMatch = true;
            TerritoryBldgData bldgData =
                TerritorySNGControl._inst._myBldgInfos.Values.FirstOrDefault(bldg =>
                    bldg._buildingType == BuildingType);

            if (bldgData == null)
            {
                _isConditionMatch = false;
                Debug.Log($"[BldgStateCondition] Condition Fail. BldgData is null. {BuildingType}/{State}/{NeedMatch}");
                yield break;
            }

            if (NeedMatch)
                _isConditionMatch = bldgData._state == State;
            else
                _isConditionMatch = bldgData._state != State;
            if (_isConditionMatch == false)
                Debug.Log($"[BldgStateCondition] Condition Fail. {BuildingType}/{State}/{NeedMatch}/{bldgData._state}");
        }
    }
    [InfoBox("건물의 존재여부 체크")]
    public class BuildingCondition : AbsConditionData
    {
        public PEnumModelProtoEnumrefBuildingTypeWrapper.Types.PEnumModelProtoEnumrefBuildingType BuildingType;
        public bool IsExist;
        public override IEnumerator CheckCondition()
        {
            TerritoryBldgData bldgData =
                TerritorySNGControl._inst._myBldgInfos.Values.FirstOrDefault(bldg =>
                    bldg._buildingType == BuildingType);

            _isConditionMatch = IsExist == (bldgData != null);
            yield break;
        }
    }
    [InfoBox("영주스킬 등록 여부 체크")]
    public class LordSkillSlotCondition : AbsConditionData
    {
        public bool IsExist = false;

        public PEnumModelProtoEnumrefLordskillCategoryTypeWrapper.Types.PEnumModelProtoEnumrefLordskillCategoryType
            CategoryType = PEnumModelProtoEnumrefLordskillCategoryTypeWrapper.Types.PEnumModelProtoEnumrefLordskillCategoryType.Pve;
        public override IEnumerator CheckCondition()
        {
            if (Player._dicLordSkillSlots.TryGetValue(CategoryType, out var skillSlots) == false)
            {
                _isConditionMatch = IsExist == false;
                yield break;
            }
            var slotCount = skillSlots.Values.Count(e => e.LordSkill != null);
            if (IsExist)
            {
                _isConditionMatch = slotCount > 0;
            }
            else
            {
                _isConditionMatch = slotCount == 0;
            }
        }
    }
}