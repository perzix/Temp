﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Fun.Engine.Pb;
using Sirenix.OdinInspector;
using Tutorial;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

[InfoBox("건물 팝업")]
public class TerritoryBldgPopupTutorialData : AbsHoleTutorialData
{
    private GameObject _prefab;
    public override string GetComment()
    {
        return $"{BuildingType} {PopupType} {TargetInfo.HoleTargetId} 튜토리얼 홀";
    }
    public enum BldgPopupType
    {
        Info,
        Upgrade
    }

    public PEnumModelProtoEnumrefBuildingTypeWrapper.Types.PEnumModelProtoEnumrefBuildingType BuildingType;
    public BldgPopupType PopupType;
    //오딘통해서 프리펩 드래그앤 드랍하면 경로가 설정될수 있게 하자
    [OnValueChanged("OnTargetInfoChange")] public FixedTargetInfo TargetInfo;
    public void OnTargetInfoChange()
    {
        if (_prefab == null)
        {
            _prefab = Util.LoadRes<GameObject>("UI/Territory/BldgPopup");
        }

        if (TargetInfo != null)
        {
            TargetInfo.OnChangePopupPrefab(_prefab);
        }

        _prefab = null;
    }

    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        TerritoryBldgData bldgData =
            TerritorySNGControl._inst._myBldgInfos.Values.FirstOrDefault(bldg =>
                bldg._buildingType == BuildingType);

        if (bldgData == null || bldgData._state != PBuildingStateEnum.Types.PBuildingState.Normal)
        {
            UIManager.Instance.ReleaseTouch(UIManager.BlockTouchType.Tutorial);
            failCallback.Invoke(bldgData == null ? "bldgData is null" : $"Need Set bldgState normal: {bldgData._state}");
            yield break;
        }

        var popup = UIManager.Instance.GetPopupUIFromList<UIBldgPopup>();
        if (popup == null)
        {
            //강제로 팝업을 띄워줌
            popup = UIManager.Instance.OpenUI<UIBldgPopup>("UI/Territory/BldgPopup");
            popup.Init(bldgData._playerBuildingID, PopupType == BldgPopupType.Info);
        }


        //고정된 버튼은 이걸 사용함
        var getter = popup.GetComponent<TutorialHoleFixedTargetGetter>();
        RectTransform holeTarget = null;
        if (getter != null)
        {
            holeTarget = getter.GetTarget(TargetInfo.HoleTargetId);
        }

        if (holeTarget != null)
        {
            yield return OpenTutorialHole(holeTarget);
        }

        if (PopupType == BldgPopupType.Upgrade)
        {
            //건물 상태가 업그레이드가 될때까지 기다림
            yield return new WaitUntil(() => bldgData._state == PBuildingStateEnum.Types.PBuildingState.Upgrade);
        }
    }
}

[InfoBox("영웅 획득 팝업")]
public class HeroRewardPopupTutorialData : AbsHoleTutorialData
{
    public override string GetComment()
    {
        return $"영웅 획득 팝업 {TutorialHoleId} 튜토리얼 홀";
    }
    public string TutorialHoleId;

    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        //튜토리얼은 넘어갔는데 아직 서버에서 응답이 안와서 팝업이 안열려있을수 있다 팝업이 열릴때까지 대기하자(최대 10초)
        var popup = UIManager.Instance.GetPopupUIFromList<UISelectCountryPopup>();
        if (popup == null)
        {
            var waitUntilWithTimeout = new WaitUntilWithTimeout(() =>
            {
                popup = UIManager.Instance.GetPopupUIFromList<UISelectCountryPopup>();
                return popup != null;
            });
            yield return waitUntilWithTimeout;
            if (waitUntilWithTimeout.IsTimeout)
            {
                failCallback.Invoke("Timeout");
                yield break;
            }
        }

        //고정된 버튼은 이걸 사용함
        var targetInfo = popup.GetComponent<TutorialHoleFixedTargetGetter>();
        RectTransform holeTarget = null;
        if (targetInfo != null)
        {
            holeTarget = targetInfo.GetTarget(TutorialHoleId);
        }

        if (holeTarget != null)
        {
            yield return OpenTutorialHole(holeTarget);
        }
    }
}

public class GarbageTutorialData : AbsHoleTutorialData
{
    public override string GetComment()
    {
        return "잔해제거";
    }
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        if (TerritorySNGControl._inst._myGarbageBldgInfos.Count <= 0)
        {
            //없으면 종료
            failCallback.Invoke("garbage count zero");
            yield break;
        }

        var first = TerritorySNGControl._inst._myGarbageBldgInfos.First();
        var trashKey = first.Key;
        TerritoryBldgData trash = first.Value;
        TerritorySNGBldg trashBldg = trash._owner.GetComponent<TerritorySNGBldg>();
        if (!trashBldg || !trashBldg.BldgStateUI ||
            !trashBldg.BldgStateUI.GarbageButton)
        {
            failCallback.Invoke("Garbage State Error");
            yield break;
        }

        TerritorySNGControl._inst.ShowSNGBldgMenuUI(trashBldg.gameObject, true);

        var garbageButton = trashBldg.BldgStateUI.GarbageButton.GetComponent<RectTransform>();
        yield return OpenTutorialHole(garbageButton);
        SaveForNextTutorial save = new SaveForNextTutorial()
        {
            WaitForResponse = false
        };
        yield return save.Process(null);
        yield return new WaitUntil(() => TerritorySNGControl._inst._myGarbageBldgInfos.ContainsKey(trashKey) == false);
    }
}

public class BuildingShopPopupTutorialData : AbsTutorialData
{
    public override string GetComment()
    {
        return $"건물상점 {PopupData.TargetInfo.HoleTargetId} 튜토리얼 홀";
    }
    public TemplatePopupTutorial<UITerritoryBuildingShopPopup> PopupData = new TemplatePopupTutorial<UITerritoryBuildingShopPopup>();
    [OnInspectorInit]
    private void OnInspectorInit()
    {
        PopupData.PrefabPath = "UI/Territory/SNG/TerritoryBuildingShopPopup";
        PopupData.OnPrefabPathChange();
    }
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        bool isSuccess = true;
        yield return PopupData.OpenPopup(() => { isSuccess = false;});
        if (isSuccess == false)
        {
            failCallback.Invoke($"UITerritoryBuildingShopPopup open Fail.");
            yield break;
        }
        yield return new WaitUntil(() => PopupData.Popup.IsLoadingFinish);
        string failMessage = "";
        yield return PopupData.Process((message)=> 
        {
            isSuccess = false;
            failMessage = message;
        });
        if (isSuccess == false)
        {
            failCallback.Invoke(failMessage);
            yield break;
        }
        
    }

    public override IEnumerator PostProcess()
    {
        yield return PopupData.PostProcess();
    }
}
public class DecoShopPopupTutorialData : AbsTutorialData
{
    public override string GetComment()
    {
        return $"꾸미기 상점 {PopupData.TargetInfo.HoleTargetId} 튜토리얼 홀";
    }
    public TemplatePopupTutorial<UITerritoryDecoShopPopup> PopupData = new TemplatePopupTutorial<UITerritoryDecoShopPopup>();
    [OnInspectorInit]
    private void OnInspectorInit()
    {
        PopupData.PrefabPath = "UI/Territory/SNG/TerritoryDecoShopPopup";
        PopupData.OnPrefabPathChange();
    }
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        bool isSuccess = true;
        yield return PopupData.OpenPopup(() => { isSuccess = false;});
        if (isSuccess == false)
        {
            failCallback.Invoke("UITerritoryDecoShopPopup open fail.");
            yield break;
        }
        yield return new WaitUntil(() => PopupData.Popup.IsLoadingFinish);
        string failMessage = "";
        yield return PopupData.Process((message) =>
        {
            isSuccess = false;
            failMessage = message;
        });
        if (isSuccess == false)
        {
            failCallback.Invoke(failMessage);
            yield break;
        }
    }

    public override IEnumerator PostProcess()
    {
        yield return PopupData.PostProcess();
    }
}

public class OpenEventPopup : AbsTutorialData
{
    public override string GetComment()
    {
        return $"{EventModelId} 이벤트 팝업열기";
    }
    public int EventModelId;
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        if (EventModelId == 0)
        {
            yield break;
        }
        UIManager.Instance.BlockTouch(99, UIManager.BlockTouchType.Tutorial);
        var eventPopup = UIManager.Instance.GetPopupUIFromList<UIEventMain>();
        if (eventPopup != null)
        {
            eventPopup.ClickTab(EventModelId);
        }
        else
        {
            eventPopup = UIManager.Instance.OpenUI<UIEventMain>("UI/Event/EventMain");
            if (eventPopup)
            {
                eventPopup.RequestedOpenEventID = EventModelId;
                yield return new WaitUntil(() => eventPopup.IsLoadingPage);
            }
        }
        if (EventManager.Instance.eventDict.Values.Where(eventSummary => EventModelId == eventSummary.EventId).ToList().Count == 0)
        {
            failCallback?.Invoke($"{EventModelId} Event Not Found");
            yield break;
        }
        UIManager.Instance.ReleaseTouch(UIManager.BlockTouchType.Tutorial);
    }
}

public class EventTutorialHole : AbsHoleTutorialData
{
    public override string GetComment()
    {
        return $"{EventModelId} 이벤트 팝업열기";
    }
    private GameObject _prefab;
    public int EventModelId;
    [OnValueChanged("OnPrefabPathChange"), InlineButton("Reload")]
    [Sirenix.OdinInspector.FilePath(ParentFolder = "Assets/ResourceBundle/", Extensions = "prefab")]
    public string PrefabPath;
    [ShowInInspector, TypeFilter("GetFilteredTypeList")] [OnValueChanged("OnTargetInfoChange")]
    public AbsTargetInfo TargetInfo;
    
    public void OnPrefabPathChange()
    {
        _prefab = null;

        _prefab = Util.LoadRes<GameObject>(PrefabPath.Replace(".prefab", ""));
        if (TargetInfo != null)
        {
            TargetInfo.OnChangePopupPrefab(_prefab);
        }
    }
    public void OnTargetInfoChange()
    {
        if (string.IsNullOrEmpty(PrefabPath))
        {
            return;
        }

        if (_prefab == null)
        {
            _prefab = Util.LoadRes<GameObject>(PrefabPath.Replace(".prefab", ""));
        }

        if (TargetInfo != null)
        {
            TargetInfo.OnChangePopupPrefab(_prefab);
        }

        _prefab = null;
    }
    private static IEnumerable<Type> _filteredTypeList;

    public IEnumerable<Type> GetFilteredTypeList()
    {
        if (_filteredTypeList == null)
        {
            _filteredTypeList = typeof(AbsTargetInfo).Assembly.GetTypes()
                .Where(x => !x.IsAbstract) // Excludes BaseClass
                .Where(x => !x.IsGenericTypeDefinition) // Excludes C1<>
                .Where(x => typeof(AbsTargetInfo)
                    .IsAssignableFrom(x)); // Excludes classes not inheriting from BaseClass    
        }

        return _filteredTypeList;
    }
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        var eventMain = UIManager.Instance.GetPopupUIFromList<UIEventMain>();
        if (eventMain == null)
        {
            OpenEventPopup openEventPopup = new OpenEventPopup()
            {
                EventModelId = EventModelId
            };
            bool isSuccess = true;
            string failMessage = "";
            yield return openEventPopup.Process((message) =>
            {
                isSuccess = false;
                failMessage = message;
            });
            yield return openEventPopup.PostProcess();
            if (isSuccess == false)
            {
                failCallback?.Invoke(failMessage);
                yield break;
            }
        }
 
        UIEventBase uiEventBase = null;
        long timeout = TimeUtil.UnixTimestampFromDateTime(TimeUtil.ServerUtcNow.AddSeconds(10f));
        while (true)
        {
            if (eventMain.ContentEvent.childCount != 0 &&
                eventMain.ContentEvent.GetChild(0).TryGetComponent<UIEventBase>(out uiEventBase) && 
                uiEventBase.Summary?.EventId == EventModelId)
            {
                break;
            }

            if (timeout < TimeUtil.GetNowTimestamp())
            {
                failCallback?.Invoke("Timeout");
                yield break;
            }
            yield return new WaitForSeconds(0.1f);
        }
        RectTransform holeTarget = null;
        switch (TargetInfo)
        {
            case FixedTargetInfo fixedTargetInfo:
            {
                var getter = uiEventBase.GetComponent<TutorialHoleFixedTargetGetter>();
                holeTarget = getter.GetTarget(fixedTargetInfo.HoleTargetId);
                break;
            }
            case ScrollTargetInfo scrollTargetInfo:
            {
                var getter = uiEventBase.GetComponent<TutorialHoleScrollTargetGetter>();
                holeTarget = getter.GetTarget(scrollTargetInfo.ScrollId, scrollTargetInfo.SlotIndex,
                    scrollTargetInfo.HoleTargetId);
                break;
            }
            case EnhancedScrollTargetInfo enhancedScrollTargetInfo:
            {
                var getter = uiEventBase.GetComponent<TutorialHoleEnhancedScrollTargetGetter>();
                holeTarget = getter.GetTarget(enhancedScrollTargetInfo.ScrollId,
                    enhancedScrollTargetInfo.DataIndex, enhancedScrollTargetInfo.HoleTargetId);
                break;
            }
        }
        

        if (holeTarget != null)
        {
            yield return new WaitUntil(() => holeTarget.gameObject.activeSelf);
            yield return OpenTutorialHole(holeTarget);
        }
    }
    private void Reload()
    {
        OnPrefabPathChange();
    }
}

public class DialogPopupTutorialHole : AbsHoleTutorialData
{
    public override string GetComment()
    {
        return $"다이얼로그 {TargetInfo.HoleTargetId} 튜토리얼 홀";
    }
    
    private GameObject _prefab;
    
    [OnValueChanged("OnPrefabPathChange"), InlineButton("Reload")]
    [Sirenix.OdinInspector.FilePath(ParentFolder = "Assets/ResourceBundle/", Extensions = "prefab")]
    public string PrefabPath;
    public FixedTargetInfo TargetInfo;
    
    public void OnPrefabPathChange()
    {
        _prefab = null;

        _prefab = Util.LoadRes<GameObject>(PrefabPath.Replace(".prefab", ""));
        if (TargetInfo != null)
        {
            TargetInfo.OnChangePopupPrefab(_prefab);
        }
    }
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        yield return new WaitUntilWithTimeout(() => UIManager.Instance.IsDialogUI());
        RectTransform holeTarget = null;

        var getter = UIManager.Instance.Dialog.GetComponent<TutorialHoleFixedTargetGetter>();
        holeTarget = getter.GetTarget(TargetInfo.HoleTargetId);
        TutorialGuide.Instance.IsOnDialog = true;

        if (holeTarget != null)
        {
            if (holeTarget.gameObject.activeSelf == false)
            {
                Debug.Log($"[DialogPopupHoleTutorialData] holtTarget waiting for active");
                yield return new WaitUntil(() => holeTarget.gameObject.activeSelf);
            }
            
            yield return OpenTutorialHole(holeTarget);
            TutorialGuide.Instance.IsOnDialog = false;
        }
    }
    private void Reload()
    {
        OnPrefabPathChange();
    }
}

[InfoBox("가챠 연출이 끝날때까지 기다림")]
public class WaitForGachaPlayDoneTutorialData : AbsTutorialData
{
    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        if (UIManager.Instance.IsGachaPlay == false)
        {
            yield return new WaitUntilWithTimeout(() => UIManager.Instance.IsGachaPlay);
        }
        //가챠연출 스킵 버튼이 있어서 블록터치를 풀어줘야함
        UIManager.Instance.ReleaseTouch(UIManager.BlockTouchType.Tutorial);
        yield return new WaitUntil(() => UIManager.Instance.IsGachaPlay == false);
    }

    public override string GetComment()
    {
        return "가챠 연출 종료 대기";
    }
}
[InfoBox("가챠 튜토리얼 진행")]
public class GachaTutorial : AbsHoleTutorialData
{
    //고급 소환이  불가능한 상태면 넘어가야 한다.
    public int GachaId;
    private GameObject _prefab;
    [OnValueChanged("OnTargetInfoChange")] public FixedTargetInfo TargetInfo;
    public void OnTargetInfoChange()
    {
        if (_prefab == null)
        {
            _prefab = Util.LoadRes<GameObject>(UIPubMainPopup.UI_PATH);
        }

        if (TargetInfo != null)
        {
            TargetInfo.OnChangePopupPrefab(_prefab);
        }

        _prefab = null;
    }
    
    public override IEnumerator Process(UnityAction<string> faillCallback)
    {
        var popup = UIManager.Instance.GetPopupUIFromList<UIPubMainPopup>();
        if (popup == null)
        {
            var bldgData = TerritorySNGControl._inst._dictMyTerritoryAllBuilding.Values.FirstOrDefault(e => e.BldgData._buildingType == PEnumModelProtoEnumrefBuildingTypeWrapper.Types.PEnumModelProtoEnumrefBuildingType.Pub);
            popup = UIManager.Instance.OpenUI<UIPubMainPopup>(UIPubMainPopup.UI_PATH);
            popup.SetSNGBldg( bldgData, true );
        }
        if (popup.IsInitPacket)
        {
            popup.SelectPickupTabById(GachaId);
        }
        else
        {
            bool isInitDone = false;
            popup._initDone = delegate
            {
                popup.SelectPickupTabById(GachaId);
                isInitDone = true;
            };
            yield return new WaitUntilWithTimeout(() => isInitDone, 10f);
        }
        var getter = popup.GetComponent<TutorialHoleFixedTargetGetter>();
        var holeTarget = getter.GetTarget(TargetInfo.HoleTargetId);
        if (holeTarget == null)
        {
            faillCallback?.Invoke($"{TargetInfo.HoleTargetId} HoleTarget not found.");
            yield break;
        }

        var button = holeTarget.GetComponent<Button>();
        if (holeTarget.gameObject.activeInHierarchy == false || (button != null && button.enabled == false))
        {
            //버튼을 누를수 없다면 실패처리하고 튜토리얼 종료
            faillCallback?.Invoke("PubMainPopup Target is not Active");
            yield break;
        }

        yield return OpenTutorialHole(holeTarget);
    }

    public override string GetComment()
    {
        return $"{GachaId} 가챠 소환 튜토리얼 홀";
    }
}

//데이터 초기화가 필요하지 않는 팝업에서만 써야한다 초기화가 필요하면 TemplatePopupTutorial를 이용한 별도의 클래스를 만들자
public class CommonPopupHoleTutorialData : AbsHoleTutorialData
{
    public override string GetComment()
    {
        return $"{_popupType} 튜토리얼 홀";
    }
    public enum ProcessType
    {
        WaitForOpen,
        ForceOpen,
        Skip,
    }

    private GameObject _prefab;
    public ProcessType Type;

    [OnValueChanged("OnPrefabPathChange"), InlineButton("Reload")]
    [Sirenix.OdinInspector.FilePath(ParentFolder = "Assets/ResourceBundle/", Extensions = "prefab")]
    public string PrefabPath;

    [DisableInEditorMode] public Type _popupType;

    public void OnPrefabPathChange()
    {
        _prefab = null;

        _prefab = Util.LoadRes<GameObject>(PrefabPath.Replace(".prefab", ""));
        if (TargetInfo != null)
        {
            TargetInfo.OnChangePopupPrefab(_prefab);
        }

        _popupType = _prefab != null ? _prefab.GetComponent<UIPopupBase>().GetType() : null;
    }

    //오딘통해서 프리펩 드래그앤 드랍하면 경로가 설정될수 있게 하자
    [ShowInInspector, TypeFilter("GetFilteredTypeList")] [OnValueChanged("OnTargetInfoChange")]
    public AbsTargetInfo TargetInfo;

    public void OnTargetInfoChange()
    {
        if (string.IsNullOrEmpty(PrefabPath))
        {
            return;
        }

        if (_prefab == null)
        {
            _prefab = Util.LoadRes<GameObject>(PrefabPath.Replace(".prefab", ""));
        }

        if (TargetInfo != null)
        {
            TargetInfo.OnChangePopupPrefab(_prefab);
        }

        _prefab = null;
    }

    private static IEnumerable<Type> _filteredTypeList;

    public IEnumerable<Type> GetFilteredTypeList()
    {
        if (_filteredTypeList == null)
        {
            _filteredTypeList = typeof(AbsTargetInfo).Assembly.GetTypes()
                .Where(x => !x.IsAbstract) // Excludes BaseClass
                .Where(x => !x.IsGenericTypeDefinition) // Excludes C1<>
                .Where(x => typeof(AbsTargetInfo)
                    .IsAssignableFrom(x)); // Excludes classes not inheriting from BaseClass    
        }

        return _filteredTypeList;
    }


    public override IEnumerator Process(UnityAction<string> failCallback)
    {
        var popup = UIManager.Instance.GetPopupUIFromList(_popupType);
        if (popup == null)
        {
            if (Type == ProcessType.Skip)
            {
                yield break;
            }
            else if (Type == ProcessType.ForceOpen)
            {
                popup = UIManager.Instance.OpenUI(PrefabPath.Replace(".prefab", ""));
            }
            else if (Type == ProcessType.WaitForOpen)
            {
                var waitUntilWithTimeout = new WaitUntilWithTimeout(() =>
                {
                    popup = UIManager.Instance.GetPopupUIFromList(_popupType);
                    return popup != null;
                });
                yield return waitUntilWithTimeout;
                if (waitUntilWithTimeout.IsTimeout)
                {
                    failCallback.Invoke("Timeout");
                    yield break;
                }
            }
        }

        RectTransform holeTarget = null;
        switch (TargetInfo)
        {
            case FixedTargetInfo fixedTargetInfo:
            {
                var getter = popup.GetComponent<TutorialHoleFixedTargetGetter>();
                holeTarget = getter.GetTarget(fixedTargetInfo.HoleTargetId);
                break;
            }
            case ScrollTargetInfo scrollTargetInfo:
            {
                var getter = popup.GetComponent<TutorialHoleScrollTargetGetter>();
                holeTarget = getter.GetTarget(scrollTargetInfo.ScrollId, scrollTargetInfo.SlotIndex,
                    scrollTargetInfo.HoleTargetId);
                break;
            }
            case EnhancedScrollTargetInfo enhancedScrollTargetInfo:
            {
                var getter = popup.GetComponent<TutorialHoleEnhancedScrollTargetGetter>();
                holeTarget = getter.GetTarget(enhancedScrollTargetInfo.ScrollId,
                    enhancedScrollTargetInfo.DataIndex, enhancedScrollTargetInfo.HoleTargetId);
                break;
            }
        }
        

        if (holeTarget != null)
        {
            var button = holeTarget.GetComponent<Button>();
            if (holeTarget.gameObject.activeInHierarchy == false || (button != null && button.enabled == false))
            {
                Debug.Log($"CommonPopupHoleTutorialData[{_popupType}] holtTarget waiting for active");
                yield return new WaitUntilWithTimeout(() => holeTarget == null || button == null  || (holeTarget.gameObject.activeInHierarchy && button.enabled), 5f);
            }
            
            yield return OpenTutorialHole(holeTarget);
        }
    }

    private void Reload()
    {
        OnPrefabPathChange();
    }
}